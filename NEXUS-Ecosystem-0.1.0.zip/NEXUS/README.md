# NEXUS Ecosystem

**Two independent applications · One NEXUS identity**

This repository contains two separate products:

- **NEXUS Local** — the supplied NEXUS 0.2.0 Python + SQLite application, preserved in its own directory.
- **NEXUS Browser** — a new static Progressive Web App. Its user workspace is persisted in the current browser profile using SQLite WASM + OPFS and OPFS file storage.

Neither product depends on the other. There is no automatic synchronization between them.

## Projects

### NEXUS Local

Open `NEXUS Local/README.md` for the original installation, upgrade and feature instructions. The Python source, static frontend, tests, and launch scripts from the uploaded 0.2.0 archive are preserved under `NEXUS Local/`.

### NEXUS Browser

Open `NEXUS Browser/README.md` for setup, development, build and deployment instructions.

The Browser edition is a static website at runtime. `npm run dev` uses Vite's development server, but the production build is static and does not need a Python process, API server, or database service.

## Important distinction

The website host serves the application code only. Workspace records and uploaded file contents are stored in the browser's origin-private storage. Browser storage is specific to the site origin and browser profile; clearing site data can erase it. Export backups regularly.

The Browser edition currently implements a foundation and a subset of the full NEXUS feature vision. Its README clearly identifies incomplete modules. Do not interpret a navigation placeholder as an implemented editor or email integration.
