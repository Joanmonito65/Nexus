#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 nexus/server.py --port 8765 &
NEXUS_PID=$!
sleep 1
if command -v open >/dev/null 2>&1; then
  open "http://127.0.0.1:8765" || true
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "http://127.0.0.1:8765" >/dev/null 2>&1 || true
fi
printf '\nNEXUS is running at http://127.0.0.1:8765\nPress Ctrl+C to stop it.\n'
trap 'kill "$NEXUS_PID" 2>/dev/null || true' EXIT INT TERM
wait "$NEXUS_PID"
