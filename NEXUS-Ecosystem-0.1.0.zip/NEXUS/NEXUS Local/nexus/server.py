#!/usr/bin/env python3
"""NEXUS local-first workspace server. Standard-library only; loopback-only."""
from __future__ import annotations

import hashlib
import html
import io
import json
import mimetypes
import os
import re
import shutil
import socket
import subprocess
import sqlite3
import sys
import threading
import time
import uuid
import zipfile
from datetime import datetime, timezone, date, time as dt_time, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
from email.parser import BytesParser
from email.policy import default as email_policy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
from urllib.parse import parse_qs, quote, unquote, urlparse

APP_VERSION = "0.2.0"
DB_SCHEMA = 2
MAX_REQUEST = 128 * 1024 * 1024
MAX_IMPORT_FILES = 10000
CONFIG_DIR = Path.home() / ".nexus-local"
CONFIG_FILE = CONFIG_DIR / "config.json"


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def new_id() -> str:
    return uuid.uuid4().hex


def json_bytes(value) -> bytes:
    return json.dumps(value, ensure_ascii=False).encode("utf-8")


def safe_name(value: str) -> str:
    value = str(value or "").replace("\\", "/").split("/")[-1]
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip(" .")
    return value[:180] or "Untitled"


def safe_rel(value: str) -> str:
    value = str(value or "").replace("\\", "/").strip("/")
    p = PurePosixPath(value)
    if p.is_absolute() or any(part in ("..", "") for part in p.parts):
        if value == "":
            return ""
        raise ValueError("Invalid relative path")
    return "/".join(p.parts)


def is_within(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


class NexusState:
    def __init__(self):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.workspace: Path | None = None
        try:
            config = json.loads(CONFIG_FILE.read_text("utf-8"))
            candidate = Path(config.get("workspace", "")).expanduser()
            if candidate.is_absolute() and candidate.exists() and candidate.is_dir():
                self.workspace = candidate.resolve()
        except Exception:
            pass

    def save_workspace(self, path: Path):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        tmp = CONFIG_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps({"workspace": str(path)}, indent=2), "utf-8")
        os.replace(tmp, CONFIG_FILE)
        self.workspace = path.resolve()
        self.initialize_workspace()

    def initialize_workspace(self):
        if not self.workspace:
            return
        root = self.workspace
        for folder in ["Database", "Files", "Documents", "Spreadsheets", "Presentations", "Notes", "Email", "Bookmarks", "Collections", "Attachments", "Backups", "Exports", "Trash/Items"]:
            (root / folder).mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(root / "Database" / "nexus.sqlite3")
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA foreign_keys=ON")
        db.executescript("""
        CREATE TABLE IF NOT EXISTS items (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, path TEXT NOT NULL,
            disk_path TEXT NOT NULL, parent_path TEXT NOT NULL DEFAULT '',
            is_folder INTEGER NOT NULL DEFAULT 0, size INTEGER NOT NULL DEFAULT 0,
            mime TEXT NOT NULL DEFAULT 'application/octet-stream',
            starred INTEGER NOT NULL DEFAULT 0, tags TEXT NOT NULL DEFAULT '[]',
            created TEXT NOT NULL, modified TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_items_parent ON items(parent_path, deleted);
        CREATE INDEX IF NOT EXISTS idx_items_path ON items(path);
        CREATE TABLE IF NOT EXISTS notes (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, content TEXT NOT NULL DEFAULT '',
            tags TEXT NOT NULL DEFAULT '[]', pinned INTEGER NOT NULL DEFAULT 0,
            created TEXT NOT NULL, modified TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS bookmarks (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, url TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '', folder TEXT NOT NULL DEFAULT '',
            tags TEXT NOT NULL DEFAULT '[]', starred INTEGER NOT NULL DEFAULT 0,
            reading_list INTEGER NOT NULL DEFAULT 0, created TEXT NOT NULL,
            modified TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS collections (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
            created TEXT NOT NULL, modified TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS collection_members (
            collection_id TEXT NOT NULL, kind TEXT NOT NULL, item_id TEXT NOT NULL,
            added TEXT NOT NULL, PRIMARY KEY(collection_id, kind, item_id),
            FOREIGN KEY(collection_id) REFERENCES collections(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY, value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS activity (
            id TEXT PRIMARY KEY, action TEXT NOT NULL, detail TEXT NOT NULL,
            created TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS app_meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS calendars (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
            color TEXT NOT NULL DEFAULT '#7665ef', visible INTEGER NOT NULL DEFAULT 1,
            created TEXT NOT NULL, modified TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS events (
            id TEXT PRIMARY KEY, calendar_id TEXT NOT NULL, title TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '', start_date TEXT NOT NULL, end_date TEXT NOT NULL,
            start_time TEXT NOT NULL DEFAULT '09:00', end_time TEXT NOT NULL DEFAULT '10:00',
            all_day INTEGER NOT NULL DEFAULT 0, timezone TEXT NOT NULL DEFAULT 'UTC',
            location TEXT NOT NULL DEFAULT '', color TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
            recurrence TEXT NOT NULL DEFAULT '{}', reminder_offsets TEXT NOT NULL DEFAULT '[]',
            important INTEGER NOT NULL DEFAULT 0, linked_items TEXT NOT NULL DEFAULT '[]',
            attachments TEXT NOT NULL DEFAULT '[]', uid TEXT NOT NULL DEFAULT '',
            created TEXT NOT NULL, modified TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(calendar_id) REFERENCES calendars(id)
        );
        CREATE INDEX IF NOT EXISTS idx_events_dates ON events(start_date, end_date, deleted);
        CREATE INDEX IF NOT EXISTS idx_events_calendar ON events(calendar_id, deleted);
        CREATE TABLE IF NOT EXISTS event_overrides (
            id TEXT PRIMARY KEY, event_id TEXT NOT NULL, occurrence_date TEXT NOT NULL,
            payload TEXT NOT NULL DEFAULT '{}', cancelled INTEGER NOT NULL DEFAULT 0,
            created TEXT NOT NULL, modified TEXT NOT NULL,
            UNIQUE(event_id, occurrence_date), FOREIGN KEY(event_id) REFERENCES events(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS task_lists (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, color TEXT NOT NULL DEFAULT '#7665ef',
            position INTEGER NOT NULL DEFAULT 0, archived INTEGER NOT NULL DEFAULT 0,
            created TEXT NOT NULL, modified TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS tasks (
            id TEXT PRIMARY KEY, list_id TEXT, parent_id TEXT, title TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '', due_date TEXT NOT NULL DEFAULT '',
            due_time TEXT NOT NULL DEFAULT '', timezone TEXT NOT NULL DEFAULT 'UTC',
            priority TEXT NOT NULL DEFAULT 'none', category TEXT NOT NULL DEFAULT '',
            tags TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL DEFAULT 'not_started',
            pinned INTEGER NOT NULL DEFAULT 0, starred INTEGER NOT NULL DEFAULT 0,
            my_day INTEGER NOT NULL DEFAULT 0, repeat_rule TEXT NOT NULL DEFAULT '{}',
            reminder_offsets TEXT NOT NULL DEFAULT '[]', notes TEXT NOT NULL DEFAULT '',
            calendar_id TEXT NOT NULL DEFAULT '', attachments TEXT NOT NULL DEFAULT '[]',
            completed_at TEXT NOT NULL DEFAULT '', archived INTEGER NOT NULL DEFAULT 0,
            created TEXT NOT NULL, modified TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY(list_id) REFERENCES task_lists(id), FOREIGN KEY(parent_id) REFERENCES tasks(id) ON DELETE CASCADE
        );
        CREATE INDEX IF NOT EXISTS idx_tasks_due ON tasks(due_date, due_time, status, deleted);
        CREATE INDEX IF NOT EXISTS idx_tasks_list ON tasks(list_id, deleted);
        CREATE TABLE IF NOT EXISTS reminders (
            id TEXT PRIMARY KEY, entity_kind TEXT NOT NULL, entity_id TEXT NOT NULL,
            occurrence_date TEXT NOT NULL DEFAULT '', offset_minutes INTEGER NOT NULL DEFAULT 0,
            label TEXT NOT NULL DEFAULT '', remind_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'scheduled', snoozed_until TEXT NOT NULL DEFAULT '',
            read_at TEXT NOT NULL DEFAULT '', notified_at TEXT NOT NULL DEFAULT '',
            created TEXT NOT NULL, modified TEXT NOT NULL,
            UNIQUE(entity_kind, entity_id, occurrence_date, offset_minutes)
        );
        CREATE INDEX IF NOT EXISTS idx_reminders_due ON reminders(status, remind_at, snoozed_until);
        INSERT OR IGNORE INTO app_meta(key, value) VALUES('schema_version', '2');
        """)
        # Safe, additive schema migration: keep all Stage 1 records intact.
        db.execute("UPDATE app_meta SET value='2' WHERE key='schema_version'")
        stamp = now_iso()
        db.execute("INSERT OR IGNORE INTO calendars(id,name,description,color,visible,created,modified) VALUES('default-personal','Personal','Your default calendar','#7665ef',1,?,?)", (stamp, stamp))
        db.execute("INSERT OR IGNORE INTO task_lists(id,name,color,position,created,modified) VALUES('default-tasks','My Tasks','#7665ef',0,?,?)", (stamp, stamp))
        db.commit()
        db.close()

    def connect(self):
        if not self.workspace:
            raise RuntimeError("Workspace is not configured")
        db = sqlite3.connect(self.workspace / "Database" / "nexus.sqlite3", timeout=15)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        return db

    def log(self, db, action: str, detail: str):
        db.execute("INSERT INTO activity(id, action, detail, created) VALUES(?,?,?,?)", (new_id(), action, detail[:300], now_iso()))
        db.execute("DELETE FROM activity WHERE id IN (SELECT id FROM activity ORDER BY created DESC LIMIT -1 OFFSET 250)")

    def storage_path(self, rel: str) -> Path:
        rel = safe_rel(rel)
        path = self.workspace.joinpath(*PurePosixPath(rel).parts) if rel else self.workspace
        if not is_within(path, self.workspace):
            raise ValueError("Path escapes the workspace")
        return path


STATE = NexusState()


def rowdict(row):
    return dict(row) if row is not None else None


def file_item(row):
    d = dict(row)
    d["tags"] = json.loads(d.get("tags") or "[]")
    d["starred"] = bool(d["starred"])
    d["is_folder"] = bool(d["is_folder"])
    d["deleted"] = bool(d["deleted"])
    return d


def parse_json_field(value, fallback=None):
    try:
        return json.loads(value) if isinstance(value, str) else (value if value is not None else fallback)
    except Exception:
        return fallback


def safe_timezone(value: str) -> str:
    value = str(value or "UTC")[:80]
    try:
        ZoneInfo(value)
        return value
    except (ZoneInfoNotFoundError, ValueError):
        return "UTC"


def recurrence_dates(start_value: str, rule_value, range_start: date, range_end: date):
    """Expand a small, RFC-like local-date recurrence rule without changing its wall-clock time."""
    start = date.fromisoformat(start_value)
    rule = parse_json_field(rule_value, {}) or {}
    freq = str(rule.get("freq", "none")).lower()
    interval = max(1, min(999, int(rule.get("interval", 1) or 1)))
    weekdays = set(int(x) for x in (rule.get("weekdays") or []) if str(x).lstrip("-").isdigit() and 0 <= int(x) <= 6)
    count = int(rule.get("count") or 0)
    until = None
    if rule.get("until"):
        try: until = date.fromisoformat(str(rule["until"]))
        except ValueError: until = None
    if freq in ("", "none", "once", "null"):
        return [start] if range_start <= start <= range_end else []
    out=[]; seen=0; cursor=start; hard_end=min(range_end, start + timedelta(days=3660))
    while cursor <= hard_end:
        days=(cursor-start).days
        months=(cursor.year-start.year)*12 + cursor.month-start.month
        match=False
        if freq == "daily": match = days % interval == 0
        elif freq == "weekdays": match = cursor.weekday() < 5 and days // 7 % interval == 0
        elif freq == "weekly":
            target_days = weekdays or {start.weekday()}
            match = days // 7 % interval == 0 and cursor.weekday() in target_days
        elif freq == "monthly":
            match = months % interval == 0 and cursor.day == start.day
        elif freq == "yearly":
            match = (cursor.year-start.year) % interval == 0 and cursor.month == start.month and cursor.day == start.day
        else:
            match = False
        if match:
            seen += 1
            if count and seen > count: break
            if until and cursor > until: break
            if cursor >= range_start: out.append(cursor)
        cursor += timedelta(days=1)
    return out


def local_to_utc(date_value: str, time_value: str, tz_name: str) -> str:
    d=date.fromisoformat(date_value)
    try: t=dt_time.fromisoformat(time_value or "09:00")
    except ValueError: t=dt_time(9,0)
    try: tz=ZoneInfo(safe_timezone(tz_name))
    except Exception: tz=timezone.utc
    aware=datetime.combine(d,t).replace(tzinfo=tz)
    return aware.astimezone(timezone.utc).isoformat(timespec="seconds")


def utc_now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ics_escape(value):
    return str(value or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def ics_unescape(value):
    return str(value or "").replace("\\n", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")


def unfold_ics(text):
    lines=[]
    for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if line.startswith((" ", "\t")) and lines: lines[-1] += line[1:]
        else: lines.append(line)
    return lines


def parse_ics_events(text):
    lines=unfold_ics(text); events=[]; current=None
    for line in lines:
        if line == "BEGIN:VEVENT": current={}; continue
        if line == "END:VEVENT":
            if current is not None: events.append(current)
            current=None; continue
        if current is None or ":" not in line: continue
        head,value=line.split(":",1); parts=head.split(";"); key=parts[0].upper(); params={}
        for part in parts[1:]:
            if "=" in part:
                k,v=part.split("=",1); params[k.upper()]=v.strip('"')
        current[key] = {"value":value,"params":params}
    parsed=[]
    day_map={"MO":0,"TU":1,"WE":2,"TH":3,"FR":4,"SA":5,"SU":6}
    for e in events:
        def get(k, default=""):
            x=e.get(k); return x.get("value",default) if isinstance(x,dict) else default
        def parse_dt(k, default_time="09:00"):
            x=e.get(k)
            if not x:return None,None,None
            raw=x["value"]; params=x.get("params",{}); tz=params.get("TZID","UTC")
            if len(raw)==8:
                d=f"{raw[:4]}-{raw[4:6]}-{raw[6:8]}"; return d,"",True
            if raw.endswith("Z"):
                raw=raw[:-1]; tz="UTC"
            if len(raw)>=15:
                d=f"{raw[:4]}-{raw[4:6]}-{raw[6:8]}"; t=f"{raw[9:11]}:{raw[11:13]}:{raw[13:15]}"; return d,t,False
            return None,None,None
        sd,st,all_day=parse_dt("DTSTART")
        ed,et,_=parse_dt("DTEND")
        if not sd: continue
        if not ed: ed=sd
        if all_day and ed:
            try: ed=(date.fromisoformat(ed)-timedelta(days=1)).isoformat()
            except ValueError: pass
        if not st: st="09:00"
        if not et: et="10:00"
        rule={}
        rraw=get("RRULE")
        if rraw:
            parts=dict(p.split("=",1) for p in rraw.split(";") if "=" in p)
            freq_map={"DAILY":"daily","WEEKLY":"weekly","MONTHLY":"monthly","YEARLY":"yearly"}
            rule={"freq":freq_map.get(parts.get("FREQ",""),"none"),"interval":int(parts.get("INTERVAL","1") or 1)}
            if parts.get("COUNT"):rule["count"]=int(parts["COUNT"])
            if parts.get("UNTIL"):
                u=parts["UNTIL"][:8]; rule["until"]=f"{u[:4]}-{u[4:6]}-{u[6:8]}"
            if parts.get("BYDAY"):
                rule["weekdays"]=[day_map[x[-2:]] for x in parts["BYDAY"].split(",") if x[-2:] in day_map]
        parsed.append({"uid":get("UID"),"title":ics_unescape(get("SUMMARY","Untitled event")),"description":ics_unescape(get("DESCRIPTION")),"location":ics_unescape(get("LOCATION")),"start_date":sd,"end_date":ed,"start_time":st,"end_time":et,"all_day":bool(all_day),"timezone":safe_timezone(e.get("DTSTART",{}).get("params",{}).get("TZID","UTC")),"recurrence":rule,"category":ics_unescape(get("CATEGORIES"))})
    return parsed


def create_unique_path(parent: Path, filename: str) -> Path:
    filename = safe_name(filename)
    candidate = parent / filename
    if not candidate.exists():
        return candidate
    stem, suffix = candidate.stem, candidate.suffix
    for n in range(1, 10000):
        candidate = parent / f"{stem} ({n}){suffix}"
        if not candidate.exists():
            return candidate
    raise RuntimeError("Too many files with the same name")


def parse_multipart(handler):
    ctype = handler.headers.get("Content-Type", "")
    length = int(handler.headers.get("Content-Length", "0"))
    if length > MAX_REQUEST: raise ValueError("Upload is larger than the 128 MB request limit")
    raw = b"Content-Type: " + ctype.encode("latin-1") + b"\r\nMIME-Version: 1.0\r\n\r\n" + handler.rfile.read(length)
    msg = BytesParser(policy=email_policy).parsebytes(raw)
    fields, files = {}, []
    for part in msg.iter_parts():
        name = part.get_param("name", header="content-disposition")
        filename = part.get_filename()
        data = part.get_payload(decode=True) or b""
        if filename is not None:
            files.append({"field": name, "filename": filename, "content_type": part.get_content_type(), "data": data})
        elif name:
            charset = part.get_content_charset() or "utf-8"
            fields[name] = data.decode(charset, "replace")
    return fields, files


class Handler(BaseHTTPRequestHandler):
    server_version = "NEXUSLocal/0.2"

    def log_message(self, fmt, *args):
        # Keep logs local and quiet; errors are still visible in the terminal.
        if args and str(args[1] if len(args) > 1 else "").startswith("5"):
            super().log_message(fmt, *args)

    def _security(self):
        host = self.headers.get("Host", "").split(":")[0].strip("[]").lower()
        if host not in ("127.0.0.1", "localhost", "::1"):
            self.send_error(403, "NEXUS only accepts local browser connections")
            return False
        if not self.client_address[0].startswith(("127.", "::1")):
            self.send_error(403, "NEXUS is loopback-only")
            return False
        origin = self.headers.get("Origin")
        if origin:
            parsed = urlparse(origin)
            if parsed.hostname not in ("127.0.0.1", "localhost", "::1"):
                self.send_error(403, "Cross-origin requests are not allowed")
                return False
        return True

    def _headers(self, content_type="application/json; charset=utf-8", length=None, extra=None):
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        if length is not None:
            self.send_header("Content-Length", str(length))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
        self.send_header("Cache-Control", "no-store")
        if extra:
            for k, v in extra.items():
                self.send_header(k, v)
        self.end_headers()

    def send_json(self, payload, status=200):
        body = json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Content-Security-Policy", "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length > MAX_REQUEST:
            raise ValueError("Request is too large")
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8")) if raw else {}

    def do_GET(self):
        if not self._security(): return
        parsed = urlparse(self.path)
        route = parsed.path
        if route == "/" or route == "/index.html":
            return self.serve_static("index.html")
        if route.startswith("/static/"):
            return self.serve_static(route.removeprefix("/static/"))
        try:
            if route == "/api/status":
                return self.send_json({"version": APP_VERSION, "configured": bool(STATE.workspace), "workspace": str(STATE.workspace) if STATE.workspace else None})
            if not STATE.workspace:
                return self.send_json({"error": "Complete local workspace setup first."}, 409)
            if route == "/api/dashboard": return self.dashboard()
            if route == "/api/files":
                q = parse_qs(parsed.query); return self.list_files(q.get("folder", [""])[0])
            if route.startswith("/api/items/"):
                return self.get_item(unquote(route.rsplit("/", 1)[-1]))
            if route == "/api/notes": return self.list_notes()
            if route == "/api/bookmarks": return self.list_bookmarks()
            if route == "/api/calendars": return self.list_calendars()
            if route == "/api/events": return self.list_events(parse_qs(parsed.query))
            if route.startswith("/api/event/"): return self.get_event(unquote(route.rsplit("/",1)[-1]))
            if route == "/api/tasks": return self.list_tasks(parse_qs(parsed.query))
            if route.startswith("/api/task/"): return self.get_task(unquote(route.rsplit("/",1)[-1]))
            if route == "/api/task-lists": return self.list_task_lists()
            if route == "/api/agenda": return self.agenda(parse_qs(parsed.query))
            if route == "/api/reminders": return self.list_reminders(parse_qs(parsed.query))
            if route == "/api/notifications": return self.list_notifications()
            if route == "/api/calendar/export.ics": return self.export_calendar_ics()
            if route == "/api/calendar/export.json": return self.export_calendar_json()
            if route == "/api/tasks/export": return self.export_tasks()
            if route == "/api/collections": return self.list_collections()
            if route == "/api/trash": return self.list_trash()
            if route == "/api/privacy": return self.privacy()
            if route == "/api/settings": return self.get_settings()
            if route == "/api/search":
                q = parse_qs(parsed.query).get("q", [""])[0]; return self.search(q)
            if route.startswith("/api/download/"):
                return self.download(unquote(route.rsplit("/", 1)[-1]))
            if route.startswith("/api/exports/"):
                name = safe_name(unquote(route.rsplit("/", 1)[-1]))
                return self.send_local_file(STATE.storage_path("Exports/" + name), download_name=name)
            if route.startswith("/api/preview/"):
                return self.preview(unquote(route.rsplit("/", 1)[-1]))
            if route.startswith("/api/collections/"):
                return self.collection_detail(unquote(route.rsplit("/", 1)[-1]))
            return self.send_json({"error": "Not found"}, 404)
        except Exception as exc:
            return self.send_json({"error": str(exc)}, 500)

    def do_POST(self):
        if not self._security(): return
        route = urlparse(self.path).path
        try:
            if route == "/api/setup": return self.setup_workspace()
            if not STATE.workspace:
                return self.send_json({"error": "Complete local workspace setup first."}, 409)
            if route == "/api/files/upload": return self.upload_files()
            if route == "/api/folders": return self.create_folder()
            if route == "/api/notes": return self.save_note()
            if route == "/api/bookmarks": return self.save_bookmark()
            if route == "/api/collections": return self.create_collection()
            if route == "/api/export": return self.create_export()
            if route == "/api/backup": return self.create_backup()
            if route == "/api/calendars": return self.create_calendar()
            if route == "/api/events": return self.create_event()
            if route == "/api/tasks": return self.create_task()
            if route == "/api/task-lists": return self.create_task_list()
            if route == "/api/calendar/import": return self.import_ics()
            if route == "/api/calendar/import/preview": return self.preview_ics_import()
            if route == "/api/calendar/import/commit": return self.commit_ics_import()
            if route == "/api/reveal": return self.reveal_workspace()
            if route == "/api/import/preview": return self.import_preview()
            if route == "/api/import/commit": return self.import_commit()
            if route.startswith("/api/items/") and route.endswith("/duplicate"):
                return self.duplicate_item(route.split("/")[3])
            if route.startswith("/api/items/") and route.endswith("/restore"):
                return self.restore_item(route.split("/")[3])
            if route.startswith("/api/trash/") and route.endswith("/restore"):
                parts = route.strip("/").split("/"); return self.restore_other(parts[2], parts[3])
            if route.startswith("/api/collections/") and route.endswith("/members"):
                return self.add_collection_member(route.split("/")[3])
            if route.startswith("/api/reminders/") and route.endswith("/snooze"):
                return self.snooze_reminder(route.split("/")[3])
            return self.send_json({"error": "Not found"}, 404)
        except Exception as exc:
            return self.send_json({"error": str(exc)}, 400)

    def do_PATCH(self):
        if not self._security(): return
        if not STATE.workspace:
            return self.send_json({"error": "Complete local workspace setup first."}, 409)
        route = urlparse(self.path).path
        try:
            data = self.read_json()
            if route.startswith("/api/items/"): return self.update_item(route.split("/")[3], data)
            if route.startswith("/api/notes/"): return self.update_note(route.rsplit("/", 1)[-1], data)
            if route.startswith("/api/bookmarks/"): return self.update_bookmark(route.rsplit("/", 1)[-1], data)
            if route.startswith("/api/calendars/"): return self.update_calendar(route.rsplit("/", 1)[-1], data)
            if route.startswith("/api/events/"): return self.update_event(route.rsplit("/", 1)[-1], data)
            if route.startswith("/api/tasks/"): return self.update_task(route.rsplit("/", 1)[-1], data)
            if route.startswith("/api/reminders/"): return self.update_reminder(route.rsplit("/", 1)[-1], data)
            if route.startswith("/api/settings"): return self.update_settings(data)
            if route.startswith("/api/collections/"): return self.update_collection(route.rsplit("/", 1)[-1], data)
            return self.send_json({"error": "Not found"}, 404)
        except Exception as exc:
            return self.send_json({"error": str(exc)}, 400)

    def do_DELETE(self):
        if not self._security(): return
        if not STATE.workspace:
            return self.send_json({"error": "Complete local workspace setup first."}, 409)
        route = urlparse(self.path).path
        try:
            if route == "/api/trash": return self.empty_trash()
            if route.startswith("/api/items/"): return self.trash_item(route.rsplit("/", 1)[-1])
            if route.startswith("/api/notes/"): return self.trash_other("note", route.rsplit("/", 1)[-1])
            if route.startswith("/api/bookmarks/"): return self.trash_other("bookmark", route.rsplit("/", 1)[-1])
            if route.startswith("/api/events/"): return self.delete_event(route.rsplit("/", 1)[-1])
            if route.startswith("/api/tasks/"): return self.delete_task(route.rsplit("/", 1)[-1])
            if route.startswith("/api/calendars/"): return self.delete_calendar(route.rsplit("/", 1)[-1])
            if route.startswith("/api/task-lists/"): return self.delete_task_list(route.rsplit("/", 1)[-1])
            if route.startswith("/api/collections/"): return self.delete_collection(route.rsplit("/", 1)[-1])
            return self.send_json({"error": "Not found"}, 404)
        except Exception as exc:
            return self.send_json({"error": str(exc)}, 400)

    def serve_static(self, rel):
        rel = safe_rel(rel)
        target = (Path(__file__).parent / "static" / rel).resolve()
        static_root = (Path(__file__).parent / "static").resolve()
        if not is_within(target, static_root) or not target.is_file():
            return self.send_error(404)
        data = target.read_bytes()
        ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if ctype in ("text/html", "text/css", "application/javascript", "text/javascript"):
            ctype += "; charset=utf-8"
        self._headers(ctype, len(data))
        self.wfile.write(data)

    def setup_workspace(self):
        data = self.read_json()
        raw = str(data.get("path", "")).strip()
        if not raw: return self.send_json({"error": "Choose a workspace folder."}, 400)
        path = Path(raw).expanduser()
        if not path.is_absolute(): return self.send_json({"error": "Enter an absolute folder path."}, 400)
        path.mkdir(parents=True, exist_ok=True)
        STATE.save_workspace(path.resolve())
        with STATE.connect() as db:
            STATE.log(db, "Workspace created", str(path.resolve()))
        return self.send_json({"ok": True, "workspace": str(path.resolve())})

    def dashboard(self):
        with STATE.connect() as db:
            counts = {
                "files": db.execute("SELECT COUNT(*) FROM items WHERE deleted=0 AND is_folder=0").fetchone()[0],
                "folders": db.execute("SELECT COUNT(*) FROM items WHERE deleted=0 AND is_folder=1").fetchone()[0],
                "notes": db.execute("SELECT COUNT(*) FROM notes WHERE deleted=0").fetchone()[0],
                "bookmarks": db.execute("SELECT COUNT(*) FROM bookmarks WHERE deleted=0").fetchone()[0],
                "collections": db.execute("SELECT COUNT(*) FROM collections").fetchone()[0],
                "trash": db.execute("SELECT (SELECT COUNT(*) FROM items WHERE deleted=1 AND (is_folder=0 OR id NOT IN (SELECT id FROM items WHERE deleted=1 AND is_folder=1))) + (SELECT COUNT(*) FROM notes WHERE deleted=1) + (SELECT COUNT(*) FROM bookmarks WHERE deleted=1)").fetchone()[0]
            }
            recent_files = [file_item(r) for r in db.execute("SELECT * FROM items WHERE deleted=0 ORDER BY modified DESC LIMIT 6")]
            recent_notes = [dict(r) for r in db.execute("SELECT id,title,modified,pinned FROM notes WHERE deleted=0 ORDER BY modified DESC LIMIT 4")]
            recent_activity = [dict(r) for r in db.execute("SELECT action,detail,created FROM activity ORDER BY created DESC LIMIT 6")]
            starred = [file_item(r) for r in db.execute("SELECT * FROM items WHERE deleted=0 AND starred=1 ORDER BY modified DESC LIMIT 5")]
        return self.send_json({"counts": counts, "recent_files": recent_files, "recent_notes": recent_notes, "recent_activity": recent_activity, "starred": starred, "workspace": str(STATE.workspace)})

    def list_files(self, folder):
        folder = safe_rel(folder)
        with STATE.connect() as db:
            rows = db.execute("SELECT * FROM items WHERE parent_path=? AND deleted=0 ORDER BY is_folder DESC, name COLLATE NOCASE", (folder,)).fetchall()
            parent = "/".join(folder.split("/")[:-1]) if folder else None
        return self.send_json({"folder": folder, "parent": parent, "items": [file_item(r) for r in rows]})

    def get_item(self, iid):
        with STATE.connect() as db:
            row = db.execute("SELECT * FROM items WHERE id=? AND deleted=0", (iid,)).fetchone()
        if not row: return self.send_json({"error": "Item not found"}, 404)
        return self.send_json({"item": file_item(row)})

    def upload_files(self):
        fields, uploads = parse_multipart(self)
        folder = safe_rel(fields.get("folder", ""))
        if not uploads: return self.send_json({"error": "No files were selected."}, 400)
        folder_disk = STATE.storage_path("Files" + ("/" + folder if folder else ""))
        folder_disk.mkdir(parents=True, exist_ok=True)
        inserted = []
        with STATE.connect() as db:
            for upload in uploads:
                name = safe_name(upload["filename"])
                dest = create_unique_path(folder_disk, name)
                with open(dest, "wb") as f: f.write(upload["data"])
                rel = (folder + "/" if folder else "") + dest.name
                st = dest.stat(); mime = upload["content_type"] or mimetypes.guess_type(dest.name)[0] or "application/octet-stream"
                iid = new_id(); stamp = now_iso(); disk = "Files/" + rel
                db.execute("INSERT INTO items(id,name,path,disk_path,parent_path,is_folder,size,mime,created,modified) VALUES(?,?,?,?,?,0,?,?,?,?)", (iid, dest.name, rel, disk, folder, st.st_size, mime, stamp, stamp))
                inserted.append({"id": iid, "name": dest.name})
            STATE.log(db, "Files imported", f"{len(inserted)} file(s) uploaded")
        return self.send_json({"ok": True, "items": inserted})

    def create_folder(self):
        data = self.read_json(); name = safe_name(data.get("name")); parent = safe_rel(data.get("parent", ""))
        parent_disk = STATE.storage_path("Files" + ("/" + parent if parent else "")); parent_disk.mkdir(parents=True, exist_ok=True)
        target = create_unique_path(parent_disk, name); target.mkdir()
        rel = (parent + "/" if parent else "") + target.name; iid = new_id(); stamp = now_iso()
        with STATE.connect() as db:
            db.execute("INSERT INTO items(id,name,path,disk_path,parent_path,is_folder,created,modified) VALUES(?,?,?,?,?,1,?,?)", (iid, target.name, rel, "Files/" + rel, parent, stamp, stamp))
            STATE.log(db, "Folder created", rel)
        return self.send_json({"ok": True, "id": iid, "name": target.name})

    def update_item(self, iid, data):
        with STATE.connect() as db:
            row = db.execute("SELECT * FROM items WHERE id=? AND deleted=0", (iid,)).fetchone()
            if not row: return self.send_json({"error": "Item not found"}, 404)
            old = dict(row); new_name = safe_name(data.get("name", old["name"])); new_parent = safe_rel(data.get("parent", old["parent_path"]))
            if new_parent:
                parent_row = db.execute("SELECT id FROM items WHERE path=? AND is_folder=1 AND deleted=0", (new_parent,)).fetchone()
                if not parent_row:
                    return self.send_json({"error": "Destination must be an existing folder in My Files."}, 400)
            parent_dir = STATE.storage_path("Files" + ("/" + new_parent if new_parent else "")); parent_dir.mkdir(parents=True, exist_ok=True)
            old_disk = STATE.storage_path(old["disk_path"])
            # Do not silently overwrite an existing target.
            new_path = (new_parent + "/" if new_parent else "") + new_name
            new_disk_rel = "Files/" + new_path
            new_disk = STATE.storage_path(new_disk_rel)
            if new_disk != old_disk and new_disk.exists():
                return self.send_json({"error": "An item with that name already exists in the destination."}, 409)
            old_prefix = old["path"]
            if old["is_folder"] and new_parent and (new_parent == old_prefix or new_parent.startswith(old_prefix + "/")):
                return self.send_json({"error": "A folder cannot be moved inside itself."}, 400)
            if old_disk != new_disk:
                shutil.move(str(old_disk), str(new_disk))
            # Update item and descendants for folder moves/renames.
            if old["is_folder"]:
                descendants = [r for r in db.execute("SELECT * FROM items WHERE id<>?", (iid,)).fetchall() if r["path"].startswith(old_prefix + "/")]
                for child in descendants:
                    suffix = child["path"][len(old_prefix):]
                    new_child_path = new_path + suffix
                    db.execute("UPDATE items SET path=?, disk_path=?, parent_path=?, modified=? WHERE id=?", (new_child_path, "Files/" + new_child_path, new_child_path.rsplit("/",1)[0], now_iso(), child["id"]))
            tags = json.dumps(data.get("tags", json.loads(old["tags"] or "[]")))
            starred = int(bool(data.get("starred", old["starred"])))
            size = new_disk.stat().st_size if new_disk.is_file() else 0
            db.execute("UPDATE items SET name=?,path=?,disk_path=?,parent_path=?,starred=?,tags=?,size=?,modified=? WHERE id=?", (new_name, new_path, new_disk_rel, new_parent, starred, tags, size, now_iso(), iid))
            STATE.log(db, "Item updated", new_path)
        return self.send_json({"ok": True})

    def duplicate_item(self, iid):
        with STATE.connect() as db:
            row = db.execute("SELECT * FROM items WHERE id=? AND deleted=0", (iid,)).fetchone()
            if not row: return self.send_json({"error": "Item not found"}, 404)
            if row["is_folder"]: return self.send_json({"error": "Folder duplication is not enabled in this build."}, 400)
            src = STATE.storage_path(row["disk_path"]); target = create_unique_path(src.parent, src.stem + " copy" + src.suffix); shutil.copy2(src, target)
            nid = new_id(); stamp = now_iso(); rel = (row["parent_path"] + "/" if row["parent_path"] else "") + target.name
            db.execute("INSERT INTO items(id,name,path,disk_path,parent_path,is_folder,size,mime,starred,tags,created,modified) VALUES(?,?,?,?,?,0,?,?,?,?,?,?)", (nid,target.name,rel,"Files/"+rel,row["parent_path"],target.stat().st_size,row["mime"],row["starred"],row["tags"],stamp,stamp))
            STATE.log(db, "File duplicated", target.name)
        return self.send_json({"ok": True, "id": nid})

    def trash_item(self, iid):
        with STATE.connect() as db:
            row = db.execute("SELECT * FROM items WHERE id=? AND deleted=0", (iid,)).fetchone()
            if not row: return self.send_json({"error": "Item not found"}, 404)
            old_path = row["path"]; src = STATE.storage_path(row["disk_path"]); target_rel = f"Trash/Items/{iid}"; target = STATE.storage_path(target_rel); target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists(): shutil.rmtree(target) if target.is_dir() else target.unlink()
            shutil.move(str(src), str(target))
            db.execute("UPDATE items SET deleted=1,disk_path=?,modified=? WHERE id=?", (target_rel, now_iso(), iid))
            if row["is_folder"]:
                descendants = [r for r in db.execute("SELECT id,path FROM items WHERE id<>? AND deleted=0", (iid,)).fetchall() if r["path"].startswith(old_path + "/")]
                for child in descendants:
                    suffix = child["path"][len(old_path):]
                    db.execute("UPDATE items SET deleted=1,disk_path=?,modified=? WHERE id=?", (target_rel + suffix, now_iso(), child["id"]))
            STATE.log(db, "Moved to trash", old_path)
        return self.send_json({"ok": True})

    def restore_item(self, iid):
        with STATE.connect() as db:
            row = db.execute("SELECT * FROM items WHERE id=? AND deleted=1", (iid,)).fetchone()
            if not row: return self.send_json({"error": "Trashed item not found"}, 404)
            original = "Files/" + row["path"]; target = STATE.storage_path(original); source = STATE.storage_path(row["disk_path"])
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists(): return self.send_json({"error": "Cannot restore: an item already exists at the original location."}, 409)
            shutil.move(str(source), str(target))
            # Restore descendants of a folder as well.
            descendants = [r["id"] for r in db.execute("SELECT id,path FROM items WHERE deleted=1").fetchall() if r["path"] == row["path"] or r["path"].startswith(row["path"] + "/")]
            for child_id in descendants:
                db.execute("UPDATE items SET deleted=0,disk_path='Files/'||path,modified=? WHERE id=?", (now_iso(), child_id))
            STATE.log(db, "Restored from trash", row["path"])
        return self.send_json({"ok": True})

    def download(self, iid):
        with STATE.connect() as db:
            row = db.execute("SELECT * FROM items WHERE id=? AND deleted=0", (iid,)).fetchone()
            if not row or row["is_folder"]: return self.send_json({"error": "File not found"}, 404)
            path = STATE.storage_path(row["disk_path"]); name = row["name"]
        return self.send_local_file(path, download_name=name)

    def send_local_file(self, path, download_name=None):
        path = path.resolve()
        if not is_within(path, STATE.workspace) or not path.is_file(): return self.send_error(404)
        size = path.stat().st_size; ctype = mimetypes.guess_type(download_name or path.name)[0] or "application/octet-stream"
        encoded = quote(download_name or path.name)
        self.send_response(200); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(size))
        self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{encoded}")
        self.send_header("X-Content-Type-Options", "nosniff"); self.send_header("Cache-Control", "no-store"); self.end_headers()
        with open(path, "rb") as f: shutil.copyfileobj(f, self.wfile)

    def preview(self, iid):
        with STATE.connect() as db:
            row = db.execute("SELECT * FROM items WHERE id=? AND deleted=0", (iid,)).fetchone()
            if not row or row["is_folder"]: return self.send_json({"error": "File not found"}, 404)
            path = STATE.storage_path(row["disk_path"])
            ext = path.suffix.lower()
            text_exts = {".txt", ".md", ".csv", ".json", ".xml", ".html", ".htm", ".css", ".js", ".ts", ".py", ".java", ".c", ".cpp", ".log", ".yaml", ".yml", ".sql", ".rtf"}
            if ext not in text_exts and not (row["mime"].startswith("text/")):
                return self.send_json({"previewable": False, "message": "This format is available for storage and download. An in-app preview is not included in this build."})
            if path.stat().st_size > 2_000_000: return self.send_json({"previewable": False, "message": "This text file is larger than the 2 MB preview limit."})
            try: content = path.read_text("utf-8", errors="replace")
            except Exception: content = "Unable to decode this file as UTF-8 text."
        return self.send_json({"previewable": True, "content": content})

    def list_notes(self):
        with STATE.connect() as db:
            rows = [dict(r) for r in db.execute("SELECT * FROM notes WHERE deleted=0 ORDER BY pinned DESC, modified DESC")]
            for r in rows: r["tags"] = json.loads(r["tags"] or "[]"); r["pinned"] = bool(r["pinned"])
        return self.send_json({"notes": rows})

    def save_note(self):
        data = self.read_json(); title = str(data.get("title") or "Untitled note").strip()[:180]; content = str(data.get("content") or "")
        if len(content) > 2_000_000: return self.send_json({"error": "Note exceeds the 2 MB text limit."}, 400)
        nid = new_id(); stamp = now_iso(); tags = json.dumps(data.get("tags") or [])
        with STATE.connect() as db:
            db.execute("INSERT INTO notes(id,title,content,tags,pinned,created,modified) VALUES(?,?,?,?,?,?,?)", (nid,title,content,tags,int(bool(data.get("pinned"))),stamp,stamp))
            STATE.log(db,"Note created",title)
        return self.send_json({"ok": True,"id":nid})

    def update_note(self, nid, data):
        title = str(data.get("title") or "Untitled note").strip()[:180]; content = str(data.get("content") or "")
        if len(content) > 2_000_000: return self.send_json({"error": "Note exceeds the 2 MB text limit."}, 400)
        with STATE.connect() as db:
            cur = db.execute("UPDATE notes SET title=?,content=?,tags=?,pinned=?,modified=? WHERE id=? AND deleted=0", (title,content,json.dumps(data.get("tags") or []),int(bool(data.get("pinned"))),now_iso(),nid))
            if not cur.rowcount: return self.send_json({"error":"Note not found"},404)
            STATE.log(db,"Note updated",title)
        return self.send_json({"ok":True})

    def trash_other(self, kind, iid):
        table = "notes" if kind == "note" else "bookmarks"
        with STATE.connect() as db:
            row = db.execute(f"SELECT * FROM {table} WHERE id=? AND deleted=0",(iid,)).fetchone()
            if not row: return self.send_json({"error":f"{kind.title()} not found"},404)
            db.execute(f"UPDATE {table} SET deleted=1,modified=? WHERE id=?",(now_iso(),iid))
            STATE.log(db,"Moved to trash",f"{kind}: {row['title'] if kind=='note' else row['title']}")
        return self.send_json({"ok":True})

    def list_bookmarks(self):
        with STATE.connect() as db:
            rows = [dict(r) for r in db.execute("SELECT * FROM bookmarks WHERE deleted=0 ORDER BY starred DESC, modified DESC")]
            for r in rows: r["tags"] = json.loads(r["tags"] or "[]"); r["starred"] = bool(r["starred"]); r["reading_list"] = bool(r["reading_list"])
        return self.send_json({"bookmarks": rows})

    def save_bookmark(self):
        data = self.read_json(); title = str(data.get("title") or "Untitled bookmark").strip()[:180]; url = str(data.get("url") or "").strip()
        p = urlparse(url)
        if p.scheme not in ("http","https") or not p.netloc: return self.send_json({"error":"Enter a valid http:// or https:// URL."},400)
        bid = new_id(); stamp = now_iso()
        with STATE.connect() as db:
            db.execute("INSERT INTO bookmarks(id,title,url,description,folder,tags,starred,reading_list,created,modified) VALUES(?,?,?,?,?,?,?,?,?,?)",(bid,title,url,str(data.get("description") or "")[:1000],str(data.get("folder") or "")[:180],json.dumps(data.get("tags") or []),int(bool(data.get("starred"))),int(bool(data.get("reading_list"))),stamp,stamp))
            STATE.log(db,"Bookmark saved",title)
        return self.send_json({"ok":True,"id":bid})

    def update_bookmark(self, bid, data):
        title = str(data.get("title") or "Untitled bookmark").strip()[:180]; url = str(data.get("url") or "").strip(); p = urlparse(url)
        if p.scheme not in ("http","https") or not p.netloc: return self.send_json({"error":"Enter a valid http:// or https:// URL."},400)
        with STATE.connect() as db:
            cur = db.execute("UPDATE bookmarks SET title=?,url=?,description=?,folder=?,tags=?,starred=?,reading_list=?,modified=? WHERE id=? AND deleted=0",(title,url,str(data.get("description") or "")[:1000],str(data.get("folder") or "")[:180],json.dumps(data.get("tags") or []),int(bool(data.get("starred"))),int(bool(data.get("reading_list"))),now_iso(),bid))
            if not cur.rowcount: return self.send_json({"error":"Bookmark not found"},404)
            STATE.log(db,"Bookmark updated",title)
        return self.send_json({"ok":True})

    def create_collection(self):
        data = self.read_json(); name = str(data.get("name") or "New collection").strip()[:120]; cid = new_id(); stamp = now_iso()
        with STATE.connect() as db:
            db.execute("INSERT INTO collections(id,name,description,created,modified) VALUES(?,?,?,?,?)",(cid,name,str(data.get("description") or "")[:500],stamp,stamp))
            STATE.log(db,"Collection created",name)
        return self.send_json({"ok":True,"id":cid})

    def list_collections(self):
        with STATE.connect() as db:
            rows = [dict(r) for r in db.execute("SELECT c.*,COUNT(m.item_id) AS item_count FROM collections c LEFT JOIN collection_members m ON m.collection_id=c.id GROUP BY c.id ORDER BY c.name COLLATE NOCASE")]
        return self.send_json({"collections":rows})

    def collection_detail(self,cid):
        with STATE.connect() as db:
            c = db.execute("SELECT * FROM collections WHERE id=?",(cid,)).fetchone()
            if not c: return self.send_json({"error":"Collection not found"},404)
            members = [dict(r) for r in db.execute("SELECT * FROM collection_members WHERE collection_id=? ORDER BY added DESC",(cid,))]
            result=[]
            for m in members:
                if m["kind"]=="file": r=db.execute("SELECT id,name,path,mime,size,is_folder,starred FROM items WHERE id=? AND deleted=0",(m["item_id"],)).fetchone()
                elif m["kind"]=="note": r=db.execute("SELECT id,title,modified FROM notes WHERE id=? AND deleted=0",(m["item_id"],)).fetchone()
                elif m["kind"]=="event": r=db.execute("SELECT id,title,start_date,start_time,end_date,calendar_id,modified FROM events WHERE id=? AND deleted=0",(m["item_id"],)).fetchone()
                elif m["kind"]=="task": r=db.execute("SELECT id,title,due_date,due_time,status,modified FROM tasks WHERE id=? AND deleted=0",(m["item_id"],)).fetchone()
                else: r=db.execute("SELECT id,title,url,modified FROM bookmarks WHERE id=? AND deleted=0",(m["item_id"],)).fetchone()
                if r: result.append({"kind":m["kind"],**dict(r)})
        return self.send_json({"collection":dict(c),"members":result})

    def add_collection_member(self,cid):
        data=self.read_json(); kind=data.get("kind"); iid=data.get("item_id")
        if kind not in ("file","note","bookmark","event","task") or not iid: return self.send_json({"error":"Choose a supported item."},400)
        table={"file":"items","note":"notes","bookmark":"bookmarks","event":"events","task":"tasks"}[kind]
        with STATE.connect() as db:
            c=db.execute("SELECT id FROM collections WHERE id=?",(cid,)).fetchone(); r=db.execute(f"SELECT id FROM {table} WHERE id=? AND deleted=0",(iid,)).fetchone()
            if not c or not r: return self.send_json({"error":"Collection or item not found"},404)
            db.execute("INSERT OR IGNORE INTO collection_members(collection_id,kind,item_id,added) VALUES(?,?,?,?)",(cid,kind,iid,now_iso()))
            db.execute("UPDATE collections SET modified=? WHERE id=?",(now_iso(),cid)); STATE.log(db,"Added to collection",kind)
        return self.send_json({"ok":True})

    def update_collection(self,cid,data):
        with STATE.connect() as db:
            cur=db.execute("UPDATE collections SET name=?,description=?,modified=? WHERE id=?",(str(data.get("name") or "Untitled collection")[:120],str(data.get("description") or "")[:500],now_iso(),cid))
            if not cur.rowcount:return self.send_json({"error":"Collection not found"},404)
        return self.send_json({"ok":True})

    def delete_collection(self,cid):
        with STATE.connect() as db:
            db.execute("DELETE FROM collections WHERE id=?",(cid,)); STATE.log(db,"Collection deleted",cid)
        return self.send_json({"ok":True})

    def list_trash(self):
        with STATE.connect() as db:
            items=db.execute("SELECT * FROM items WHERE deleted=1 ORDER BY modified DESC").fetchall(); deleted_paths={r["path"] for r in items if r["is_folder"]}
            visible=[]
            for r in items:
                ancestors=r["path"].split("/")[:-1]
                if any("/".join(ancestors[:i]) in deleted_paths for i in range(1,len(ancestors)+1)): continue
                visible.append({"kind":"file","id":r["id"],"name":r["name"],"path":r["path"],"is_folder":bool(r["is_folder"]),"modified":r["modified"]})
            notes=[{"kind":"note","id":r["id"],"name":r["title"],"modified":r["modified"]} for r in db.execute("SELECT id,title,modified FROM notes WHERE deleted=1")]
            bookmarks=[{"kind":"bookmark","id":r["id"],"name":r["title"],"modified":r["modified"]} for r in db.execute("SELECT id,title,modified FROM bookmarks WHERE deleted=1")]
        return self.send_json({"items":visible+notes+bookmarks})

    def restore_other(self,kind,iid):
        table="notes" if kind=="note" else "bookmarks"
        with STATE.connect() as db:
            cur=db.execute(f"UPDATE {table} SET deleted=0,modified=? WHERE id=? AND deleted=1",(now_iso(),iid))
            if not cur.rowcount:return self.send_json({"error":"Item not found"},404)
            STATE.log(db,"Restored from trash",kind)
        return self.send_json({"ok":True})

    def empty_trash(self):
        with STATE.connect() as db:
            rows=db.execute("SELECT id,disk_path FROM items WHERE deleted=1").fetchall()
            for r in rows:
                p=STATE.storage_path(r["disk_path"])
                if p.exists(): shutil.rmtree(p) if p.is_dir() else p.unlink()
            db.execute("DELETE FROM items WHERE deleted=1"); db.execute("DELETE FROM notes WHERE deleted=1"); db.execute("DELETE FROM bookmarks WHERE deleted=1")
            STATE.log(db,"Trash emptied","Permanently deleted trashed items")
        return self.send_json({"ok":True})

    # ---------------- Calendar, planner, and local reminders (Stage 2) ----------------
    def list_calendars(self):
        with STATE.connect() as db:
            rows=db.execute("SELECT c.*,COUNT(e.id) AS event_count FROM calendars c LEFT JOIN events e ON e.calendar_id=c.id AND e.deleted=0 WHERE c.deleted=0 GROUP BY c.id ORDER BY c.name COLLATE NOCASE").fetchall()
        return self.send_json({"calendars":[{**dict(r),"visible":bool(r["visible"])} for r in rows]})

    def create_calendar(self):
        data=self.read_json(); name=str(data.get("name") or "New calendar").strip()[:100]
        if not name:return self.send_json({"error":"Calendar name is required."},400)
        color=str(data.get("color") or "#7665ef")[:20]; stamp=now_iso(); cid=new_id()
        with STATE.connect() as db:
            db.execute("INSERT INTO calendars(id,name,description,color,visible,created,modified) VALUES(?,?,?,?,1,?,?)",(cid,name,str(data.get("description") or "")[:500],color,stamp,stamp))
            STATE.log(db,"Calendar created",name)
        return self.send_json({"ok":True,"id":cid})

    def update_calendar(self,cid,data):
        with STATE.connect() as db:
            row=db.execute("SELECT * FROM calendars WHERE id=? AND deleted=0",(cid,)).fetchone()
            if not row:return self.send_json({"error":"Calendar not found."},404)
            name=str(data.get("name",row["name"]) or row["name"]).strip()[:100]
            db.execute("UPDATE calendars SET name=?,description=?,color=?,visible=?,modified=? WHERE id=?",(name,str(data.get("description",row["description"]) or "")[:500],str(data.get("color",row["color"]) or row["color"])[:20],int(bool(data.get("visible",row["visible"]))),now_iso(),cid))
            STATE.log(db,"Calendar updated",name)
        return self.send_json({"ok":True})

    def delete_calendar(self,cid):
        with STATE.connect() as db:
            if cid=="default-personal":return self.send_json({"error":"The default Personal calendar cannot be deleted."},400)
            count=db.execute("SELECT COUNT(*) FROM events WHERE calendar_id=? AND deleted=0",(cid,)).fetchone()[0]
            if count:return self.send_json({"error":f"This calendar still contains {count} event(s). Move or delete them first."},409)
            cur=db.execute("UPDATE calendars SET deleted=1,modified=? WHERE id=?",(now_iso(),cid))
            if not cur.rowcount:return self.send_json({"error":"Calendar not found."},404)
            STATE.log(db,"Calendar deleted",cid)
        return self.send_json({"ok":True})

    def _event_dict(self,row):
        d=dict(row)
        for key in ("recurrence","reminder_offsets","linked_items","attachments"):
            d[key]=parse_json_field(d.get(key),[] if key!="recurrence" else {})
        d["all_day"]=bool(d["all_day"]);d["important"]=bool(d["important"])
        return d

    def _event_payload(self,data,existing=None):
        base=dict(existing or {})
        def value(key,default=""):
            return data.get(key,base.get(key,default))
        title=str(value("title","Untitled event") or "Untitled event").strip()[:180]
        start_date=str(value("start_date",date.today().isoformat()))
        end_date=str(value("end_date",start_date) or start_date)
        date.fromisoformat(start_date);date.fromisoformat(end_date)
        if end_date < start_date:raise ValueError("Event end date must be on or after its start date.")
        start_time=str(value("start_time","09:00") or "09:00")[:8]
        end_time=str(value("end_time","10:00") or "10:00")[:8]
        if not bool(value("all_day",False)):
            dt_time.fromisoformat(start_time);dt_time.fromisoformat(end_time)
        recurrence=value("recurrence",{}) or {}
        if isinstance(recurrence,str):recurrence=parse_json_field(recurrence,{}) or {}
        if recurrence.get("freq") not in (None,"","none","daily","weekdays","weekly","monthly","yearly"):
            raise ValueError("Unsupported recurrence frequency.")
        recurrence={"freq":recurrence.get("freq","none"),"interval":max(1,min(999,int(recurrence.get("interval",1) or 1))),"weekdays":recurrence.get("weekdays",[]),"count":int(recurrence.get("count") or 0),"until":recurrence.get("until") or ""}
        offsets=value("reminder_offsets",[]) or []
        offsets=sorted(set(max(0,min(10080,int(x))) for x in offsets))
        return {"title":title,"description":str(value("description"))[:10000],"start_date":start_date,"end_date":end_date,"start_time":start_time,"end_time":end_time,"all_day":int(bool(value("all_day",False))),"timezone":safe_timezone(value("timezone","UTC")),"location":str(value("location"))[:500],"color":str(value("color"))[:20],"category":str(value("category"))[:100],"notes":str(value("notes"))[:10000],"recurrence":json.dumps(recurrence),"reminder_offsets":json.dumps(offsets),"important":int(bool(value("important",False))),"linked_items":json.dumps(value("linked_items",[]) or []),"attachments":json.dumps(value("attachments",[]) or [])}

    def get_event(self,eid):
        with STATE.connect() as db:
            row=db.execute("SELECT e.*,c.name AS calendar_name,c.color AS calendar_color,c.visible AS calendar_visible FROM events e JOIN calendars c ON c.id=e.calendar_id WHERE e.id=? AND e.deleted=0",(eid,)).fetchone()
        if not row:return self.send_json({"error":"Event not found."},404)
        return self.send_json({"event":self._event_dict(row)})

    def create_event(self):
        data=self.read_json(); payload=self._event_payload(data); eid=new_id(); stamp=now_iso(); cid=data.get("calendar_id") or "default-personal"
        with STATE.connect() as db:
            if not db.execute("SELECT 1 FROM calendars WHERE id=? AND deleted=0",(cid,)).fetchone():return self.send_json({"error":"Choose an existing calendar."},400)
            cols=list(payload); values=[payload[k] for k in cols]
            db.execute(f"INSERT INTO events(id,calendar_id,{','.join(cols)},uid,created,modified) VALUES(?, ?, {','.join('?' for _ in cols)},?,?,?)",[eid,cid,*values,str(data.get("uid") or new_id()),stamp,stamp])
            STATE.log(db,"Event created",payload["title"])
            self._sync_reminder_queue(db)
        return self.send_json({"ok":True,"id":eid})

    def list_events(self,query):
        today=date.today(); start=query.get("start",[(today.replace(day=1)).isoformat()])[0]; end=query.get("end",[(today+timedelta(days=45)).isoformat()])[0]
        ds=date.fromisoformat(start); de=date.fromisoformat(end)
        if (de-ds).days>1100:raise ValueError("Calendar range is limited to about three years per request.")
        calendar_filter=query.get("calendar",[""])[0]
        with STATE.connect() as db:
            rows=db.execute("SELECT e.*,c.name AS calendar_name,c.color AS calendar_color,c.visible AS calendar_visible FROM events e JOIN calendars c ON c.id=e.calendar_id WHERE e.deleted=0 AND c.deleted=0 AND (?='' OR e.calendar_id=?) AND (e.start_date<=? OR json_extract(e.recurrence,'$.freq')<>'none') ORDER BY e.start_date,e.start_time LIMIT 2000",(calendar_filter,calendar_filter,end)).fetchall()
            output=[]
            for row in rows:
                e=self._event_dict(row); rule=e["recurrence"]
                if not e["calendar_visible"]:continue
                occs=recurrence_dates(e["start_date"],rule,ds,de)
                duration=(date.fromisoformat(e["end_date"])-date.fromisoformat(e["start_date"])).days
                for od in occs:
                    ov=db.execute("SELECT payload,cancelled FROM event_overrides WHERE event_id=? AND occurrence_date=?",(e["id"],od.isoformat())).fetchone()
                    if ov and ov["cancelled"]:continue
                    item={**e,"occurrence_date":od.isoformat(),"display_start_date":od.isoformat(),"display_end_date":(od+timedelta(days=duration)).isoformat(),"instance_key":e["id"]+"@"+od.isoformat()}
                    if ov:
                        item.update(parse_json_field(ov["payload"],{}) or {})
                        item["occurrence_date"]=od.isoformat();item["instance_key"]=e["id"]+"@"+od.isoformat()
                        item["display_start_date"]=item.get("start_date",od.isoformat());item["display_end_date"]=item.get("end_date",item["display_start_date"])
                    output.append(item)
        output.sort(key=lambda x:(x.get("display_start_date",x["start_date"]),x.get("start_time",""),x["title"].lower()))
        return self.send_json({"events":output,"start":start,"end":end})

    def update_event(self,eid,data):
        scope=str(data.get("scope","series")); occurrence=str(data.get("occurrence_date") or "")
        with STATE.connect() as db:
            row=db.execute("SELECT * FROM events WHERE id=? AND deleted=0",(eid,)).fetchone()
            if not row:return self.send_json({"error":"Event not found."},404)
            old=self._event_dict(row)
            if scope=="this" and occurrence:
                date.fromisoformat(occurrence)
                allowed={k:data[k] for k in ("title","description","start_date","end_date","start_time","end_time","all_day","timezone","location","color","category","notes","important","reminder_offsets") if k in data}
                if any(k in allowed for k in ("start_date","start_time","timezone","reminder_offsets")):
                    db.execute("DELETE FROM reminders WHERE entity_kind='event' AND entity_id=? AND occurrence_date=? AND status IN ('scheduled','snoozed')",(eid,occurrence))
                db.execute("INSERT INTO event_overrides(id,event_id,occurrence_date,payload,cancelled,created,modified) VALUES(?,?,?,?,0,?,?) ON CONFLICT(event_id,occurrence_date) DO UPDATE SET payload=excluded.payload,modified=excluded.modified,cancelled=0",(new_id(),eid,occurrence,json.dumps(allowed),now_iso(),now_iso()))
                STATE.log(db,"Event occurrence updated",old["title"])
                self._sync_reminder_queue(db)
                return self.send_json({"ok":True,"scope":"this"})
            payload=self._event_payload(data,old)
            target_calendar=data.get("calendar_id",old["calendar_id"])
            if not db.execute("SELECT 1 FROM calendars WHERE id=? AND deleted=0",(target_calendar,)).fetchone():return self.send_json({"error":"Choose an existing calendar."},400)
            schedule_changed=any(old.get(k) != payload[k] for k in ("start_date","start_time","end_date","timezone")) or old.get("reminder_offsets",[]) != parse_json_field(payload.get("reminder_offsets"),[]) or old.get("recurrence",{}) != parse_json_field(payload.get("recurrence"),{})
            if scope != "future" and schedule_changed:
                db.execute("DELETE FROM reminders WHERE entity_kind='event' AND entity_id=? AND status IN ('scheduled','snoozed')",(eid,))
            if scope=="future" and occurrence and old["recurrence"].get("freq") not in (None,"","none"):
                split=date.fromisoformat(occurrence); old_start=date.fromisoformat(old["start_date"])
                rule=old["recurrence"].copy(); count=int(rule.get("count") or 0)
                before=recurrence_dates(old["start_date"],rule,old_start,split-timedelta(days=1))
                if count:
                    rule["count"]=len(before);db.execute("UPDATE events SET recurrence=?,modified=? WHERE id=?",(json.dumps(rule),now_iso(),eid))
                    new_rule=payload.get("recurrence",{})
                    new_rule=json.loads(new_rule) if isinstance(new_rule,str) else new_rule
                    new_rule["count"]=max(1,count-len(before));payload["recurrence"]=json.dumps(new_rule)
                else:
                    rule["until"]=(split-timedelta(days=1)).isoformat();db.execute("UPDATE events SET recurrence=?,modified=? WHERE id=?",(json.dumps(rule),now_iso(),eid))
                duration=(date.fromisoformat(old["end_date"])-old_start).days
                payload["start_date"]=split.isoformat();payload["end_date"]=(split+timedelta(days=duration)).isoformat()
                new_eid=new_id(); cols=list(payload)
                db.execute(f"INSERT INTO events(id,calendar_id,{','.join(cols)},uid,created,modified) VALUES(?, ?, {','.join('?' for _ in cols)},?,?,?)",[new_eid,target_calendar,*[payload[k] for k in cols],new_id(),now_iso(),now_iso()])
                db.execute("UPDATE event_overrides SET event_id=?,modified=? WHERE event_id=? AND occurrence_date>=?",(new_eid,now_iso(),eid,split.isoformat()))
            else:
                cols=list(payload);db.execute("UPDATE events SET calendar_id=?,"+",".join(k+"=?" for k in cols)+",modified=? WHERE id=?",[target_calendar,*[payload[k] for k in cols],now_iso(),eid])
            STATE.log(db,"Event updated",payload["title"])
            self._sync_reminder_queue(db)
        return self.send_json({"ok":True})

    def delete_event(self,eid):
        query=parse_qs(urlparse(self.path).query);scope=query.get("scope",["series"])[0];occ=query.get("occurrence",[""])[0]
        with STATE.connect() as db:
            row=db.execute("SELECT * FROM events WHERE id=? AND deleted=0",(eid,)).fetchone()
            if not row:return self.send_json({"error":"Event not found."},404)
            if scope=="this" and occ:
                db.execute("INSERT INTO event_overrides(id,event_id,occurrence_date,payload,cancelled,created,modified) VALUES(?,?,?,'{}',1,?,?) ON CONFLICT(event_id,occurrence_date) DO UPDATE SET cancelled=1,modified=excluded.modified",(new_id(),eid,occ,now_iso(),now_iso()))
                db.execute("UPDATE reminders SET status='dismissed',modified=? WHERE entity_kind='event' AND entity_id=? AND occurrence_date=? AND status IN ('scheduled','snoozed')",(now_iso(),eid,occ))
            else:
                db.execute("UPDATE events SET deleted=1,modified=? WHERE id=?",(now_iso(),eid))
                db.execute("UPDATE reminders SET status='dismissed',modified=? WHERE entity_kind='event' AND entity_id=? AND status IN ('scheduled','snoozed')",(now_iso(),eid))
            STATE.log(db,"Event deleted",row["title"])
        return self.send_json({"ok":True})

    def list_task_lists(self):
        with STATE.connect() as db:
            rows=db.execute("SELECT l.*,COUNT(t.id) AS task_count FROM task_lists l LEFT JOIN tasks t ON t.list_id=l.id AND t.deleted=0 AND t.parent_id IS NULL WHERE l.archived=0 GROUP BY l.id ORDER BY l.position,l.name").fetchall()
        return self.send_json({"lists":[dict(r) for r in rows]})

    def create_task_list(self):
        data=self.read_json();name=str(data.get("name") or "New list").strip()[:100]
        if not name:return self.send_json({"error":"List name is required."},400)
        lid=new_id();stamp=now_iso()
        with STATE.connect() as db:
            pos=db.execute("SELECT COALESCE(MAX(position),0)+1 FROM task_lists").fetchone()[0]
            db.execute("INSERT INTO task_lists(id,name,color,position,created,modified) VALUES(?,?,?,?,?,?)",(lid,name,str(data.get("color") or "#7665ef"),pos,stamp,stamp));STATE.log(db,"Task list created",name)
        return self.send_json({"ok":True,"id":lid})

    def delete_task_list(self,lid):
        if lid=="default-tasks":return self.send_json({"error":"The default task list cannot be deleted."},400)
        with STATE.connect() as db:
            db.execute("UPDATE tasks SET list_id='default-tasks',modified=? WHERE list_id=?",(now_iso(),lid))
            cur=db.execute("DELETE FROM task_lists WHERE id=?",(lid,))
            if not cur.rowcount:return self.send_json({"error":"Task list not found."},404)
            STATE.log(db,"Task list deleted",lid)
        return self.send_json({"ok":True})

    def _task_dict(self,row):
        d=dict(row)
        for key in ("tags","repeat_rule","reminder_offsets","attachments"):
            d[key]=parse_json_field(d.get(key),[] if key!="repeat_rule" else {})
        for key in ("pinned","starred","my_day","archived","deleted"):
            if key in d:d[key]=bool(d[key])
        return d

    def _task_payload(self,data,existing=None):
        base=dict(existing or {})
        def val(k,default=""):return data.get(k,base.get(k,default))
        title=str(val("title","Untitled task") or "Untitled task").strip()[:180]
        due_date=str(val("due_date","") or "")
        if due_date:date.fromisoformat(due_date)
        due_time=str(val("due_time","") or "")[:8]
        if due_time:dt_time.fromisoformat(due_time)
        priority=str(val("priority","none"))
        if priority not in ("none","low","medium","high","urgent"):priority="none"
        status=str(val("status","not_started"))
        if status not in ("not_started","in_progress","completed","cancelled"):status="not_started"
        repeat=val("repeat_rule",{}) or {}; offsets=val("reminder_offsets",[]) or []
        return {"list_id":val("list_id","default-tasks") or "default-tasks","parent_id":val("parent_id",None) or None,"title":title,"description":str(val("description"))[:10000],"due_date":due_date,"due_time":due_time,"timezone":safe_timezone(val("timezone","UTC")),"priority":priority,"category":str(val("category"))[:100],"tags":json.dumps(val("tags",[]) or []),"status":status,"pinned":int(bool(val("pinned",False))),"starred":int(bool(val("starred",False))),"my_day":int(bool(val("my_day",False))),"repeat_rule":json.dumps(repeat),"reminder_offsets":json.dumps(sorted(set(max(0,min(10080,int(x))) for x in offsets))),"notes":str(val("notes"))[:10000],"calendar_id":str(val("calendar_id"))[:80],"attachments":json.dumps(val("attachments",[]) or []),"completed_at":str(val("completed_at", "") or (now_iso() if status=="completed" else "")),"archived":int(bool(val("archived",False)))}

    def create_task(self):
        data=self.read_json();payload=self._task_payload(data);tid=new_id();stamp=now_iso()
        with STATE.connect() as db:
            if payload["list_id"] and not db.execute("SELECT 1 FROM task_lists WHERE id=?",(payload["list_id"],)).fetchone():return self.send_json({"error":"Choose an existing task list."},400)
            if payload["parent_id"] and not db.execute("SELECT 1 FROM tasks WHERE id=? AND deleted=0",(payload["parent_id"],)).fetchone():return self.send_json({"error":"Parent task not found."},404)
            cols=list(payload);db.execute(f"INSERT INTO tasks(id,{','.join(cols)},created,modified) VALUES(?,{','.join('?' for _ in cols)},?,?)",[tid,*[payload[k] for k in cols],stamp,stamp])
            STATE.log(db,"Task created",payload["title"]);self._sync_reminder_queue(db)
        return self.send_json({"ok":True,"id":tid})

    def list_tasks(self,query):
        flt=query.get("filter",["all"])[0]; list_id=query.get("list",[""])[0]; q=query.get("q",[""])[0].strip().lower(); today=date.today().isoformat()
        where=["deleted=0","parent_id IS NULL"];params=[]
        if list_id:where.append("list_id=?");params.append(list_id)
        if flt=="today":where.append("due_date=?");params.append(today)
        elif flt=="myday":where.append("(my_day=1 OR due_date=?)");params.append(today)
        elif flt=="upcoming":where.append("due_date>=? AND status NOT IN ('completed','cancelled')");params.append(today)
        elif flt=="overdue":where.append("due_date<>'' AND due_date<? AND status NOT IN ('completed','cancelled')");params.append(today)
        elif flt=="completed":where.append("status='completed'")
        elif flt=="active":where.append("status NOT IN ('completed','cancelled')")
        if q:where.append("(lower(title) LIKE ? OR lower(description) LIKE ? OR lower(notes) LIKE ?)");params.extend([f"%{q}%"]*3)
        with STATE.connect() as db:
            rows=db.execute("SELECT * FROM tasks WHERE "+" AND ".join(where)+" ORDER BY CASE priority WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 WHEN 'low' THEN 3 ELSE 4 END,due_date,due_time,created DESC",params).fetchall()
            tasks=[self._task_dict(r) for r in rows]
            for t in tasks:
                t["subtasks"]=[self._task_dict(x) for x in db.execute("SELECT * FROM tasks WHERE parent_id=? AND deleted=0 ORDER BY created",(t["id"],)).fetchall()]
                t["subtask_count"]=len(t["subtasks"]);t["subtask_completed"]=sum(1 for x in t["subtasks"] if x["status"]=="completed")
        return self.send_json({"tasks":tasks,"filter":flt})

    def get_task(self,tid):
        with STATE.connect() as db:
            row=db.execute("SELECT * FROM tasks WHERE id=? AND deleted=0",(tid,)).fetchone()
            if not row:return self.send_json({"error":"Task not found."},404)
            task=self._task_dict(row);task["subtasks"]=[self._task_dict(x) for x in db.execute("SELECT * FROM tasks WHERE parent_id=? AND deleted=0 ORDER BY created",(tid,)).fetchall()]
        return self.send_json({"task":task})

    def update_task(self,tid,data):
        with STATE.connect() as db:
            row=db.execute("SELECT * FROM tasks WHERE id=? AND deleted=0",(tid,)).fetchone()
            if not row:return self.send_json({"error":"Task not found."},404)
            old=self._task_dict(row);payload=self._task_payload(data,old);cols=list(payload)
            new_offsets=parse_json_field(payload.get("reminder_offsets"),[]) or []
            if any(old.get(k) != payload.get(k) for k in ("due_date","due_time","timezone")) or old.get("reminder_offsets",[]) != new_offsets:
                db.execute("DELETE FROM reminders WHERE entity_kind='task' AND entity_id=? AND status IN ('scheduled','snoozed')",(tid,))
            db.execute("UPDATE tasks SET "+",".join(k+"=?" for k in cols)+",modified=? WHERE id=?",[*[payload[k] for k in cols],now_iso(),tid])
            if payload["status"]=="completed" and old["status"]!="completed" and not old["parent_id"]:
                rule=parse_json_field(payload["repeat_rule"],{}) or {}
                if rule.get("freq") in ("daily","weekdays","weekly","monthly","yearly") and payload["due_date"]:
                    next_day=date.fromisoformat(payload["due_date"])
                    freq=rule["freq"];interval=max(1,int(rule.get("interval",1) or 1))
                    if freq=="daily":next_day+=timedelta(days=interval)
                    elif freq=="weekdays":
                        for _ in range(interval):
                            next_day+=timedelta(days=1)
                            while next_day.weekday()>=5:next_day+=timedelta(days=1)
                    elif freq=="weekly":next_day+=timedelta(weeks=interval)
                    elif freq=="monthly":
                        m=next_day.month-1+interval;y=next_day.year+m//12;m=m%12+1
                        import calendar as _cal
                        next_day=date(y,m,min(next_day.day,_cal.monthrange(y,m)[1]))
                    elif freq=="yearly":
                        try:next_day=next_day.replace(year=next_day.year+interval)
                        except ValueError:next_day=next_day.replace(year=next_day.year+interval,day=28)
                    if not rule.get("until") or next_day.isoformat()<=rule["until"]:
                        nxt=dict(payload);nxt["due_date"]=next_day.isoformat();nxt["status"]="not_started";nxt["completed_at"]="";nxt["my_day"]=0
                        nid=new_id();ncols=list(nxt);db.execute(f"INSERT INTO tasks(id,{','.join(ncols)},created,modified) VALUES(?,{','.join('?' for _ in ncols)},?,?)",[nid,*[nxt[k] for k in ncols],now_iso(),now_iso()])
            if payload["status"] in ("completed","cancelled"):
                db.execute("UPDATE reminders SET status='dismissed',modified=? WHERE entity_kind='task' AND entity_id=? AND status IN ('scheduled','snoozed')",(now_iso(),tid))
            STATE.log(db,"Task updated",payload["title"]);self._sync_reminder_queue(db)
        return self.send_json({"ok":True})

    def delete_task(self,tid):
        with STATE.connect() as db:
            row=db.execute("SELECT title FROM tasks WHERE id=? AND deleted=0",(tid,)).fetchone()
            if not row:return self.send_json({"error":"Task not found."},404)
            ids=[tid];ids.extend(r[0] for r in db.execute("SELECT id FROM tasks WHERE parent_id=? AND deleted=0",(tid,)).fetchall())
            db.executemany("UPDATE tasks SET deleted=1,modified=? WHERE id=?",[(now_iso(),x) for x in ids])
            db.execute("UPDATE reminders SET status='dismissed',modified=? WHERE entity_kind='task' AND entity_id IN ("+','.join('?' for _ in ids)+")",[now_iso(),*ids])
            STATE.log(db,"Task deleted",row["title"])
        return self.send_json({"ok":True})

    def agenda(self,query):
        today=date.today();start=query.get("start",[today.isoformat()])[0];end=query.get("end",[(today+timedelta(days=30)).isoformat()])[0]
        evq={"start":[start],"end":[end]};
        # Use the same expansion logic as the Calendar endpoint, without writing a response first.
        ds=date.fromisoformat(start);de=date.fromisoformat(end);events=[];tasks=[]
        with STATE.connect() as db:
            rows=db.execute("SELECT e.*,c.name AS calendar_name,c.color AS calendar_color,c.visible AS calendar_visible FROM events e JOIN calendars c ON c.id=e.calendar_id WHERE e.deleted=0 AND c.deleted=0 AND (e.start_date<=? OR json_extract(e.recurrence,'$.freq')<>'none')",(end,)).fetchall()
            for row in rows:
                e=self._event_dict(row)
                if not e["calendar_visible"]:continue
                duration=(date.fromisoformat(e["end_date"])-date.fromisoformat(e["start_date"])).days
                for od in recurrence_dates(e["start_date"],e["recurrence"],ds,de):
                    ov=db.execute("SELECT payload,cancelled FROM event_overrides WHERE event_id=? AND occurrence_date=?",(e["id"],od.isoformat())).fetchone()
                    if ov and ov["cancelled"]:continue
                    it={**e,"display_start_date":od.isoformat(),"display_end_date":(od+timedelta(days=duration)).isoformat(),"occurrence_date":od.isoformat()}
                    if ov:it.update(parse_json_field(ov["payload"],{}) or {})
                    events.append(it)
            for row in db.execute("SELECT * FROM tasks WHERE deleted=0 AND status NOT IN ('completed','cancelled') AND due_date>=? AND due_date<=? ORDER BY due_date,due_time",(start,end)):
                t=self._task_dict(row);tasks.append(t)
        timeline=[{"kind":"event",**e} for e in events]+[{"kind":"task",**t} for t in tasks]
        timeline.sort(key=lambda x:(x.get("display_start_date",x.get("due_date","9999")),x.get("start_time",x.get("due_time","23:59")),x["title"].lower()))
        return self.send_json({"items":timeline,"start":start,"end":end})

    def _sync_reminder_queue(self,db):
        today=date.today();start=today-timedelta(days=1);end=today+timedelta(days=120)
        evs=db.execute("SELECT * FROM events WHERE deleted=0").fetchall()
        for row in evs:
            e=self._event_dict(row)
            duration=(date.fromisoformat(e["end_date"])-date.fromisoformat(e["start_date"])).days
            for od in recurrence_dates(e["start_date"],e["recurrence"],start,end):
                ov=db.execute("SELECT cancelled,payload FROM event_overrides WHERE event_id=? AND occurrence_date=?",(e["id"],od.isoformat())).fetchone()
                if ov and ov["cancelled"]:continue
                payload=parse_json_field(ov["payload"],{}) or {} if ov else {}
                offsets=parse_json_field(payload.get("reminder_offsets"),e["reminder_offsets"]) or []
                if not offsets:
                    db.execute("DELETE FROM reminders WHERE entity_kind='event' AND entity_id=? AND occurrence_date=? AND status IN ('scheduled','snoozed')",(e["id"],od.isoformat()))
                    continue
                sd=payload.get("start_date",od.isoformat()); st=payload.get("start_time",e["start_time"])
                for offset in offsets:
                    when=datetime.fromisoformat(local_to_utc(sd,st,e["timezone"]))-timedelta(minutes=int(offset))
                    rid=new_id();label=e["title"];stamp=now_iso()
                    db.execute("INSERT INTO reminders(id,entity_kind,entity_id,occurrence_date,offset_minutes,label,remind_at,status,created,modified) VALUES(?,?,?,?,?,?,?,'scheduled',?,?) ON CONFLICT(entity_kind,entity_id,occurrence_date,offset_minutes) DO UPDATE SET label=excluded.label,remind_at=excluded.remind_at,modified=excluded.modified WHERE reminders.status IN ('scheduled','snoozed')",(rid,"event",e["id"],od.isoformat(),int(offset),label,when.isoformat(timespec="seconds"),stamp,stamp))
        trs=db.execute("SELECT * FROM tasks WHERE deleted=0 AND status NOT IN ('completed','cancelled')").fetchall()
        for row in trs:
            t=self._task_dict(row)
            if not t["due_date"] or not t["reminder_offsets"]:
                db.execute("DELETE FROM reminders WHERE entity_kind='task' AND entity_id=? AND status IN ('scheduled','snoozed')",(t["id"],))
                continue
            db.execute("DELETE FROM reminders WHERE entity_kind='task' AND entity_id=? AND occurrence_date<>? AND status IN ('scheduled','snoozed')",(t["id"],t["due_date"]))
            for offset in t["reminder_offsets"]:
                when=datetime.fromisoformat(local_to_utc(t["due_date"],t["due_time"] or "09:00",t["timezone"]))-timedelta(minutes=int(offset))
                stamp=now_iso()
                db.execute("INSERT INTO reminders(id,entity_kind,entity_id,occurrence_date,offset_minutes,label,remind_at,status,created,modified) VALUES(?,?,?,?,?,?,?,'scheduled',?,?) ON CONFLICT(entity_kind,entity_id,occurrence_date,offset_minutes) DO UPDATE SET label=excluded.label,remind_at=excluded.remind_at,modified=excluded.modified WHERE reminders.status IN ('scheduled','snoozed')",(new_id(),"task",t["id"],t["due_date"],int(offset),t["title"],when.isoformat(timespec="seconds"),stamp,stamp))

    def list_reminders(self,query):
        with STATE.connect() as db:
            self._sync_reminder_queue(db)
            rows=db.execute("SELECT * FROM reminders WHERE status IN ('scheduled','snoozed') ORDER BY COALESCE(NULLIF(snoozed_until,''),remind_at) LIMIT 100").fetchall()
        return self.send_json({"reminders":[dict(r) for r in rows]})

    def list_notifications(self):
        with STATE.connect() as db:
            self._sync_reminder_queue(db)
            rows=db.execute("SELECT * FROM reminders WHERE status IN ('notified','missed','read','scheduled','snoozed') ORDER BY CASE status WHEN 'missed' THEN 0 WHEN 'notified' THEN 1 WHEN 'read' THEN 2 ELSE 3 END,COALESCE(NULLIF(snoozed_until,''),remind_at) DESC LIMIT 100").fetchall()
        return self.send_json({"notifications":[dict(r) for r in rows]})

    def update_reminder(self,rid,data):
        action=data.get("action","read");status="dismissed" if action=="dismiss" else "read"
        with STATE.connect() as db:
            cur=db.execute("UPDATE reminders SET status=?,read_at=?,modified=? WHERE id=?",(status,now_iso(),now_iso(),rid))
            if not cur.rowcount:return self.send_json({"error":"Reminder not found."},404)
        return self.send_json({"ok":True})

    def snooze_reminder(self,rid):
        data=self.read_json();mins=max(1,min(10080,int(data.get("minutes",10))))
        until=(datetime.now(timezone.utc)+timedelta(minutes=mins)).isoformat(timespec="seconds")
        with STATE.connect() as db:
            cur=db.execute("UPDATE reminders SET status='snoozed',snoozed_until=?,modified=? WHERE id=?",(until,now_iso(),rid))
            if not cur.rowcount:return self.send_json({"error":"Reminder not found."},404)
        return self.send_json({"ok":True,"snoozed_until":until})

    def import_ics(self):
        return self.preview_ics_import()

    def preview_ics_import(self):
        fields,uploads=parse_multipart(self)
        if not uploads:return self.send_json({"error":"Choose an .ics calendar file."},400)
        up=uploads[0]
        if not up["filename"].lower().endswith((".ics",".ical")):return self.send_json({"error":"Calendar import accepts .ics or .ical files."},400)
        parsed=parse_ics_events(up["data"].decode("utf-8-sig","replace"))
        with STATE.connect() as db:
            known={r[0] for r in db.execute("SELECT uid FROM events WHERE uid<>'' AND deleted=0")}
            duplicate_count=sum(1 for x in parsed if x.get("uid") and x["uid"] in known)
        token=new_id();stage=STATE.storage_path("Exports/.staging");stage.mkdir(parents=True,exist_ok=True)
        (stage/(token+".ics.json")).write_text(json.dumps(parsed,ensure_ascii=False),"utf-8")
        return self.send_json({"ok":True,"preview":{"token":token,"filename":up["filename"],"events":len(parsed),"duplicates":duplicate_count,"new_events":len(parsed)-duplicate_count}})

    def commit_ics_import(self):
        data=self.read_json();token=str(data.get("token") or "")
        if not re.fullmatch(r"[a-f0-9]{32}",token):return self.send_json({"error":"Invalid import token."},400)
        stage=STATE.storage_path("Exports/.staging")/(token+".ics.json")
        if not stage.is_file():return self.send_json({"error":"Calendar import preview expired."},400)
        incoming=json.loads(stage.read_text("utf-8"));stamp=now_iso();imported=0;duplicates=0
        with STATE.connect() as db:
            for e in incoming:
                uid=str(e.get("uid") or "")
                if uid and db.execute("SELECT 1 FROM events WHERE uid=? AND deleted=0",(uid,)).fetchone():duplicates+=1;continue
                data={**e,"calendar_id":"default-personal"};payload=self._event_payload(data);cols=list(payload);eid=new_id()
                db.execute(f"INSERT INTO events(id,calendar_id,{','.join(cols)},uid,created,modified) VALUES(?, ?, {','.join('?' for _ in cols)},?,?,?)",[eid,"default-personal",*[payload[k] for k in cols],uid or new_id(),stamp,stamp]);imported+=1
            self._sync_reminder_queue(db);STATE.log(db,"Calendar imported",f"{imported} event(s)")
        stage.unlink(missing_ok=True)
        return self.send_json({"ok":True,"imported":imported,"duplicates":duplicates})

    def export_calendar_ics(self):
        query=parse_qs(urlparse(self.path).query);cid=query.get("calendar",[""])[0]
        with STATE.connect() as db:
            params=[];where="deleted=0"
            if cid:where+=" AND calendar_id=?";params.append(cid)
            rows=db.execute("SELECT * FROM events WHERE "+where+" ORDER BY start_date,start_time",params).fetchall()
        lines=["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//NEXUS//Local Calendar 0.2//EN","CALSCALE:GREGORIAN"]
        for row in rows:
            e=self._event_dict(row); lines.extend(["BEGIN:VEVENT","UID:"+ics_escape(e.get("uid") or e["id"]),"DTSTAMP:"+datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")])
            if e["all_day"]:
                sd=e["start_date"].replace("-","");ed=(date.fromisoformat(e["end_date"])+timedelta(days=1)).strftime("%Y%m%d")
                lines.extend(["DTSTART;VALUE=DATE:"+sd,"DTEND;VALUE=DATE:"+ed])
            else:
                tz=safe_timezone(e["timezone"]); lines.extend([f"DTSTART;TZID={tz}:"+e["start_date"].replace("-","")+"T"+e["start_time"].replace(":","")[:6],f"DTEND;TZID={tz}:"+e["end_date"].replace("-","")+"T"+e["end_time"].replace(":","")[:6]])
            for key,field in (("SUMMARY","title"),("DESCRIPTION","description"),("LOCATION","location"),("CATEGORIES","category")):
                if e.get(field):lines.append(key+":"+ics_escape(e[field]))
            r=e["recurrence"]
            if r.get("freq") not in (None,"","none"):
                parts=["FREQ="+{"daily":"DAILY","weekdays":"DAILY","weekly":"WEEKLY","monthly":"MONTHLY","yearly":"YEARLY"}.get(r["freq"],"DAILY")]
                if int(r.get("interval",1))>1:parts.append("INTERVAL="+str(r["interval"]))
                if r.get("count"):parts.append("COUNT="+str(r["count"]))
                if r.get("until"):parts.append("UNTIL="+r["until"].replace("-",""))
                if r.get("freq")=="weekdays":parts.append("BYDAY=MO,TU,WE,TH,FR")
                elif r.get("weekdays"):parts.append("BYDAY="+",".join(["MO","TU","WE","TH","FR","SA","SU"][int(x)] for x in r["weekdays"] if 0<=int(x)<=6))
                lines.append("RRULE:"+";".join(parts))
            lines.append("END:VEVENT")
        lines.append("END:VCALENDAR");body=("\r\n".join(lines)+"\r\n").encode("utf-8");name="NEXUS-calendar.ics"
        self.send_response(200);self.send_header("Content-Type","text/calendar; charset=utf-8");self.send_header("Content-Disposition",f'attachment; filename="{name}"');self.send_header("Content-Length",str(len(body)));self.send_header("X-Content-Type-Options","nosniff");self.end_headers();self.wfile.write(body)

    def export_calendar_json(self):
        query=parse_qs(urlparse(self.path).query);cid=query.get("calendar",[""])[0]
        with STATE.connect() as db:
            params=[];where="deleted=0"
            if cid:where+=" AND id=?";params.append(cid)
            calendars=[dict(r) for r in db.execute("SELECT * FROM calendars WHERE deleted=0"+(" AND id=?" if cid else "")+" ORDER BY name",params)]
            event_params=[];event_where="deleted=0"
            if cid:event_where+=" AND calendar_id=?";event_params.append(cid)
            events=[dict(r) for r in db.execute("SELECT * FROM events WHERE "+event_where+" ORDER BY start_date,start_time",event_params)]
            event_ids=[e["id"] for e in events]
            overrides=[];reminders=[]
            if event_ids:
                marks=",".join("?" for _ in event_ids)
                overrides=[dict(r) for r in db.execute(f"SELECT * FROM event_overrides WHERE event_id IN ({marks})",event_ids)]
                reminders=[dict(r) for r in db.execute(f"SELECT * FROM reminders WHERE entity_kind='event' AND entity_id IN ({marks})",event_ids)]
        payload={"format":"NEXUS_CALENDAR","version":1,"exported_at":now_iso(),"calendars":calendars,"events":events,"event_overrides":overrides,"reminders":reminders}
        body=json.dumps(payload,ensure_ascii=False,indent=2).encode("utf-8");name="NEXUS-calendar.json"
        self.send_response(200);self.send_header("Content-Type","application/json; charset=utf-8");self.send_header("Content-Disposition",f'attachment; filename="{name}"');self.send_header("Content-Length",str(len(body)));self.send_header("X-Content-Type-Options","nosniff");self.end_headers();self.wfile.write(body)

    def export_tasks(self):
        query=parse_qs(urlparse(self.path).query);fmt=query.get("format",["json"])[0]
        with STATE.connect() as db:rows=[self._task_dict(r) for r in db.execute("SELECT * FROM tasks WHERE deleted=0 ORDER BY due_date,due_time")]
        if fmt=="csv":
            import csv
            buf=io.StringIO();writer=csv.DictWriter(buf,fieldnames=["id","list_id","parent_id","title","description","due_date","due_time","priority","status","category","tags","notes","my_day","repeat_rule","reminder_offsets"]);writer.writeheader()
            for x in rows:writer.writerow({k:json.dumps(x[k]) if isinstance(x.get(k),(list,dict)) else x.get(k,"") for k in writer.fieldnames})
            body=buf.getvalue().encode("utf-8-sig");ctype="text/csv; charset=utf-8";name="NEXUS-tasks.csv"
        else:
            body=json.dumps({"format":"NEXUS_TASKS","version":1,"tasks":rows},ensure_ascii=False,indent=2).encode("utf-8");ctype="application/json; charset=utf-8";name="NEXUS-tasks.json"
        self.send_response(200);self.send_header("Content-Type",ctype);self.send_header("Content-Disposition",f'attachment; filename="{name}"');self.send_header("Content-Length",str(len(body)));self.send_header("X-Content-Type-Options","nosniff");self.end_headers();self.wfile.write(body)


    def search(self,q):
        q=str(q or "").strip()[:200]
        if not q:return self.send_json({"query":q,"results":[]})
        like="%"+q.replace("%","\\%").replace("_","\\_")+"%"; out=[]
        with STATE.connect() as db:
            for r in db.execute("SELECT id,name,path,mime,size,is_folder,modified FROM items WHERE deleted=0 AND (name LIKE ? ESCAPE '\\' OR path LIKE ? ESCAPE '\\') LIMIT 30",(like,like)):
                out.append({"kind":"file","id":r["id"],"title":r["name"],"subtitle":r["path"],"modified":r["modified"],"is_folder":bool(r["is_folder"])})
            for r in db.execute("SELECT id,title,substr(content,1,180) AS preview,modified FROM notes WHERE deleted=0 AND (title LIKE ? OR content LIKE ?) LIMIT 20",(like,like)):
                out.append({"kind":"note","id":r["id"],"title":r["title"],"subtitle":r["preview"],"modified":r["modified"]})
            for r in db.execute("SELECT id,title,url,modified FROM bookmarks WHERE deleted=0 AND (title LIKE ? OR url LIKE ? OR description LIKE ?) LIMIT 20",(like,like,like)):
                out.append({"kind":"bookmark","id":r["id"],"title":r["title"],"subtitle":r["url"],"modified":r["modified"]})
            for r in db.execute("SELECT id,title,start_date,start_time,category FROM events WHERE deleted=0 AND (title LIKE ? OR description LIKE ? OR location LIKE ? OR notes LIKE ?) LIMIT 25",(like,like,like,like)):
                out.append({"kind":"event","id":r["id"],"title":r["title"],"subtitle":r["start_date"]+" · "+r["start_time"],"modified":r["start_date"]})
            for r in db.execute("SELECT id,title,due_date,due_time,status,modified FROM tasks WHERE deleted=0 AND (title LIKE ? OR description LIKE ? OR notes LIKE ?) LIMIT 25",(like,like,like)):
                out.append({"kind":"task","id":r["id"],"title":r["title"],"subtitle":(r["due_date"] or "No due date")+" · "+r["status"],"modified":r["modified"]})
        return self.send_json({"query":q,"results":out})

    def get_settings(self):
        with STATE.connect() as db: data={r["key"]:json.loads(r["value"]) for r in db.execute("SELECT * FROM settings")}
        return self.send_json({"settings":data,"workspace":str(STATE.workspace)})

    def update_settings(self,data):
        with STATE.connect() as db:
            for k,v in data.items():
                if k not in ("theme","accent","sidebar_collapsed","dashboard_widgets","quiet_hours_enabled","quiet_hours_start","quiet_hours_end","notification_sound"):continue
                db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,json.dumps(v)))
            STATE.log(db,"Settings updated","Appearance and workspace preferences")
        return self.send_json({"ok":True})

    def reveal_workspace(self):
        root = str(STATE.workspace)
        try:
            if sys.platform == "win32":
                os.startfile(root)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", root], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                subprocess.Popen(["xdg-open", root], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception as exc:
            return self.send_json({"error": f"Could not open the folder automatically. Use the displayed path instead. ({exc})"}, 500)
        return self.send_json({"ok": True})

    def privacy(self):
        root=STATE.workspace
        def size_of(p):
            total=0
            if p.exists():
                for f in p.rglob("*"):
                    try:
                        if f.is_file():total+=f.stat().st_size
                    except OSError:pass
            return total
        dbp=root/"Database"/"nexus.sqlite3"
        with STATE.connect() as db:
            activity=[dict(r) for r in db.execute("SELECT action,detail,created FROM activity ORDER BY created DESC LIMIT 12")]
            productivity={"calendars":db.execute("SELECT COUNT(*) FROM calendars WHERE deleted=0").fetchone()[0],"events":db.execute("SELECT COUNT(*) FROM events WHERE deleted=0").fetchone()[0],"tasks":db.execute("SELECT COUNT(*) FROM tasks WHERE deleted=0").fetchone()[0],"reminders":db.execute("SELECT COUNT(*) FROM reminders").fetchone()[0]}
        usage={"files":size_of(root/"Files"),"documents":size_of(root/"Documents"),"spreadsheets":size_of(root/"Spreadsheets"),"presentations":size_of(root/"Presentations"),"email":size_of(root/"Email"),"attachments":size_of(root/"Attachments"),"backups":size_of(root/"Backups"),"exports":size_of(root/"Exports"),"database":dbp.stat().st_size if dbp.exists() else 0}
        usage["total"] = sum(usage.values())
        try:
            disk = shutil.disk_usage(root); usage["disk_total"] = disk.total; usage["disk_free"] = disk.free
        except OSError:
            usage["disk_total"] = 0; usage["disk_free"] = 0
        return self.send_json({"workspace":str(root),"usage":usage,"connected_email_accounts":[],"local_only_features":True,"external_connections":"No email providers are connected in this build. Opening bookmarks is an external browser action; optional favicon fetching is not enabled.","activity":activity,"credentials":"NEXUS 0.2 does not store email credentials or OAuth tokens.","productivity":productivity,"productivity_storage":"Calendars, events, tasks, recurring rules, and reminder history are stored in the local SQLite database under Database/nexus.sqlite3."})

    def create_export(self, destination="Exports"):
        with STATE.connect() as db:
            workspace={
                "schema_version":DB_SCHEMA,
                "items":[dict(r) for r in db.execute("SELECT * FROM items WHERE deleted=0")],
                "notes":[dict(r) for r in db.execute("SELECT * FROM notes WHERE deleted=0")],
                "bookmarks":[dict(r) for r in db.execute("SELECT * FROM bookmarks WHERE deleted=0")],
                "collections":[dict(r) for r in db.execute("SELECT * FROM collections")],
                "collection_members":[dict(r) for r in db.execute("SELECT * FROM collection_members")],
                "settings":[dict(r) for r in db.execute("SELECT * FROM settings")],
                "activity":[dict(r) for r in db.execute("SELECT * FROM activity")],
                "calendars":[dict(r) for r in db.execute("SELECT * FROM calendars WHERE deleted=0")],
                "events":[dict(r) for r in db.execute("SELECT * FROM events WHERE deleted=0")],
                "event_overrides":[dict(r) for r in db.execute("SELECT * FROM event_overrides")],
                "task_lists":[dict(r) for r in db.execute("SELECT * FROM task_lists")],
                "tasks":[dict(r) for r in db.execute("SELECT * FROM tasks WHERE deleted=0")],
                "reminders":[dict(r) for r in db.execute("SELECT * FROM reminders")]
            }
            STATE.log(db,"Backup created" if destination=="Backups" else "Data exported","Complete local workspace archive")
        timestamp=datetime.now().strftime("%Y%m%d-%H%M%S")
        outdir=STATE.storage_path(destination); outdir.mkdir(parents=True,exist_ok=True)
        filename=f"NEXUS-{ 'backup' if destination=='Backups' else 'export'}-{timestamp}.zip"
        outpath=outdir/filename
        payload_files=[]
        with zipfile.ZipFile(outpath,"w",zipfile.ZIP_DEFLATED,compresslevel=6) as zf:
            db_source=STATE.storage_path("Database/nexus.sqlite3")
            # The logical JSON snapshot is the portable schema layer. Hash it as well as payload file bytes.
            workspace_bytes=json.dumps(workspace,ensure_ascii=False,indent=2).encode("utf-8")
            workspace_hash=hashlib.sha256(workspace_bytes).hexdigest()
            zf.writestr("workspace.json",workspace_bytes)
            for folder in ["Files","Documents","Spreadsheets","Presentations","Notes","Email","Bookmarks","Collections","Attachments"]:
                base=STATE.storage_path(folder)
                for f in base.rglob("*"):
                    if not f.is_file():continue
                    rel=f.relative_to(STATE.workspace).as_posix()
                    arc="payload/"+rel
                    zf.write(f,arc)
                    data_hash=hashlib.sha256(f.read_bytes()).hexdigest()
                    payload_files.append({"path":arc,"size":f.stat().st_size,"sha256":data_hash})
            zf.writestr("manifest.json",json.dumps({"format":"NEXUS_BACKUP","version":1,"app_version":APP_VERSION,"created":now_iso(),"workspace_schema":DB_SCHEMA,"workspace_sha256":workspace_hash,"file_count":len(payload_files),"files":payload_files,"secrets_excluded":True},indent=2))
        return self.send_json({"ok":True,"filename":filename,"download_url":"/api/exports/"+quote(filename),"size":outpath.stat().st_size})

    def create_backup(self):
        return self.create_export("Backups")

    def import_preview(self):
        fields,uploads=parse_multipart(self)
        if not uploads:return self.send_json({"error":"Choose a NEXUS backup ZIP file."},400)
        upload=uploads[0]
        if not upload["filename"].lower().endswith(".zip"):return self.send_json({"error":"Import currently accepts NEXUS ZIP backups only."},400)
        stage=STATE.storage_path("Exports/.staging"); stage.mkdir(parents=True,exist_ok=True)
        token=new_id(); path=stage/(token+".zip"); path.write_bytes(upload["data"])
        try:
            with zipfile.ZipFile(path) as zf:
                names=zf.namelist()
                if len(names)>MAX_IMPORT_FILES:raise ValueError("Archive contains too many entries")
                total_uncompressed=sum(info.file_size for info in zf.infolist())
                if total_uncompressed>512*1024*1024:raise ValueError("Backup expands beyond the 512 MB import safety limit")
                if any(info.file_size>128*1024*1024 for info in zf.infolist()):raise ValueError("A backup file exceeds the 128 MB per-file import safety limit")
                for n in names:
                    p=PurePosixPath(n)
                    if p.is_absolute() or ".." in p.parts:raise ValueError("Archive contains an unsafe path")
                if "manifest.json" not in names or "workspace.json" not in names:raise ValueError("This ZIP is not a supported NEXUS backup.")
                manifest=json.loads(zf.read("manifest.json")); workspace_bytes=zf.read("workspace.json"); workspace=json.loads(workspace_bytes)
                if manifest.get("format")!="NEXUS_BACKUP":raise ValueError("Unrecognized NEXUS backup format")
                expected_workspace_hash=manifest.get("workspace_sha256")
                if expected_workspace_hash and hashlib.sha256(workspace_bytes).hexdigest()!=expected_workspace_hash:raise ValueError("Workspace snapshot integrity check failed.")
                for entry in manifest.get("files",[]):
                    name=entry["path"]
                    if name not in names:raise ValueError(f"Missing backup file: {name}")
                    content=zf.read(name)
                    if hashlib.sha256(content).hexdigest()!=entry["sha256"]:raise ValueError(f"Integrity check failed: {name}")
                preview={"filename":upload["filename"],"token":token,"created":manifest.get("created"),"file_count":manifest.get("file_count",0),"notes":len(workspace.get("notes",[])),"bookmarks":len(workspace.get("bookmarks",[])),"collections":len(workspace.get("collections",[])),"calendars":len(workspace.get("calendars",[])),"events":len(workspace.get("events",[])),"tasks":len(workspace.get("tasks",[])),"reminders":len(workspace.get("reminders",[])),"email_cache_included":bool(workspace.get("email")),"verified":True}
        except Exception:
            path.unlink(missing_ok=True); raise
        return self.send_json({"ok":True,"preview":preview})

    def import_commit(self):
        data=self.read_json(); token=str(data.get("token") or ""); strategy=data.get("strategy","merge")
        if strategy not in ("merge","collection"):
            return self.send_json({"error":"This build supports Merge or Import into a new collection. Workspace replacement is not enabled."},400)
        stage=STATE.storage_path("Exports/.staging")/(token+".zip")
        if not re.fullmatch(r"[a-f0-9]{32}",token) or not stage.is_file():
            return self.send_json({"error":"Import preview expired. Select the ZIP again."},400)
        imported=0
        try:
            with zipfile.ZipFile(stage) as zf:
                workspace=json.loads(zf.read("workspace.json"))
                manifest=json.loads(zf.read("manifest.json"))
                with STATE.connect() as db:
                    stamp=now_iso()
                    # Keep an imported backup's original relative hierarchy intact under one new top-level folder.
                    import_root=f"Imported {datetime.now().strftime('%Y-%m-%d %H-%M-%S')}"
                    root_disk=STATE.storage_path("Files/"+import_root)
                    suffix=1
                    while root_disk.exists():
                        import_root=f"Imported {datetime.now().strftime('%Y-%m-%d %H-%M-%S')} ({suffix})"; suffix+=1
                        root_disk=STATE.storage_path("Files/"+import_root)
                    root_disk.mkdir(parents=True,exist_ok=True)
                    root_id=new_id()
                    db.execute("INSERT INTO items(id,name,path,disk_path,parent_path,is_folder,size,mime,starred,tags,created,modified,deleted) VALUES(?,?,?,?,?,1,0,?,?,?,?,?,0)",(root_id,import_root,import_root,"Files/"+import_root,"", "application/x-directory",0,"[]",stamp,stamp))
                    idmap={}
                    if strategy=="collection":
                        collection_id=new_id()
                        db.execute("INSERT INTO collections(id,name,description,created,modified) VALUES(?,?,?,?,?)",(collection_id,"Imported workspace",f"Imported from {stage.name}",stamp,stamp))
                    else:
                        collection_id=None
                    # Insert folders before files, then preserve each item's path inside the import root.
                    source_items=workspace.get("items",[])
                    source_items=sorted(source_items,key=lambda x:(not bool(x.get("is_folder")),x.get("path","" ).count("/"),x.get("path","")))
                    for item in source_items:
                        oldid=item["id"]; newitem=new_id(); idmap["file:"+oldid]=newitem
                        oldpath=safe_rel(item.get("path","")); oldparent=safe_rel(item.get("parent_path",""))
                        newpath=import_root+"/"+oldpath
                        newparent=import_root+("/"+oldparent if oldparent else "")
                        name=safe_name(item["name"])
                        dest=STATE.storage_path("Files/"+newpath); dest.parent.mkdir(parents=True,exist_ok=True)
                        archive="payload/Files/"+oldpath
                        if item.get("is_folder"):
                            dest.mkdir(parents=True,exist_ok=True)
                        elif archive in zf.namelist():
                            dest.write_bytes(zf.read(archive))
                        else:
                            idmap.pop("file:"+oldid,None)
                            continue
                        db.execute("INSERT INTO items(id,name,path,disk_path,parent_path,is_folder,size,mime,starred,tags,created,modified,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)",(newitem,name,newpath,"Files/"+newpath,newparent,int(item.get("is_folder",0)),dest.stat().st_size if dest.is_file() else 0,item.get("mime","application/octet-stream"),item.get("starred",0),item.get("tags","[]"),item.get("created",stamp),stamp))
                        imported+=1
                    for note in workspace.get("notes",[]):
                        nid=new_id();idmap["note:"+note["id"]]=nid
                        db.execute("INSERT INTO notes(id,title,content,tags,pinned,created,modified,deleted) VALUES(?,?,?,?,?,?,?,0)",(nid,note["title"],note.get("content",""),note.get("tags","[]"),note.get("pinned",0),note.get("created",stamp),stamp))
                        if collection_id:db.execute("INSERT INTO collection_members(collection_id,kind,item_id,added) VALUES(?,?,?,?)",(collection_id,"note",nid,stamp))
                        imported+=1
                    for bm in workspace.get("bookmarks",[]):
                        bid=new_id();idmap["bookmark:"+bm["id"]]=bid
                        db.execute("INSERT INTO bookmarks(id,title,url,description,folder,tags,starred,reading_list,created,modified,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,0)",(bid,bm["title"],bm["url"],bm.get("description",""),bm.get("folder",""),bm.get("tags","[]"),bm.get("starred",0),bm.get("reading_list",0),bm.get("created",stamp),stamp))
                        if collection_id:db.execute("INSERT INTO collection_members(collection_id,kind,item_id,added) VALUES(?,?,?,?)",(collection_id,"bookmark",bid,stamp))
                        imported+=1
                    # Import local calendars, event series, tasks, subtasks, and reminder history.
                    calendar_map={}
                    for cal in workspace.get("calendars",[]):
                        cid=new_id();calendar_map[cal["id"]]=cid
                        db.execute("INSERT INTO calendars(id,name,description,color,visible,created,modified,deleted) VALUES(?,?,?,?,?,?,?,0)",(cid,str(cal.get("name","Calendar"))+" (imported)",cal.get("description",""),cal.get("color","#7665ef"),cal.get("visible",1),cal.get("created",stamp),stamp))
                    if not calendar_map:
                        calendar_map["default-personal"]="default-personal"
                    for ev in workspace.get("events",[]):
                        nid=new_id();idmap["event:"+ev["id"]]=nid;cols=[k for k in ev.keys() if k not in ("id","created","modified","deleted")]
                        values=[]
                        for k in cols:
                            v=ev[k]
                            if k=="calendar_id":v=calendar_map.get(v,"default-personal")
                            values.append(v)
                        db.execute(f"INSERT INTO events(id,{','.join(cols)},created,modified,deleted) VALUES(?,{','.join('?' for _ in cols)},?, ?,0)",[nid,*values,ev.get("created",stamp),stamp])
                        imported+=1
                    for ov in workspace.get("event_overrides",[]):
                        mapped=idmap.get("event:"+ov.get("event_id",""))
                        if mapped:db.execute("INSERT INTO event_overrides(id,event_id,occurrence_date,payload,cancelled,created,modified) VALUES(?,?,?,?,?,?,?)",(new_id(),mapped,ov["occurrence_date"],ov.get("payload","{}"),ov.get("cancelled",0),ov.get("created",stamp),stamp))
                    list_map={}
                    for tasklist in workspace.get("task_lists",[]):
                        lid=new_id();list_map[tasklist["id"]]=lid
                        db.execute("INSERT INTO task_lists(id,name,color,position,archived,created,modified) VALUES(?,?,?,?,?,?,?)",(lid,tasklist.get("name","Tasks")+" (imported)",tasklist.get("color","#7665ef"),tasklist.get("position",0),tasklist.get("archived",0),tasklist.get("created",stamp),stamp))
                    # Insert parent tasks first, then children, preserving subtask relationships.
                    pending=list(workspace.get("tasks",[])); task_map={}
                    while pending:
                        progressed=False
                        for task in pending[:]:
                            parent=task.get("parent_id")
                            if parent and parent not in task_map:continue
                            tid=new_id();task_map[task["id"]]=tid;idmap["task:"+task["id"]]=tid
                            cols=[k for k in task.keys() if k not in ("id","created","modified","deleted")]
                            values=[]
                            for k in cols:
                                v=task[k]
                                if k=="list_id":v=list_map.get(v,"default-tasks")
                                elif k=="parent_id":v=task_map.get(v) if v else None
                                elif k=="calendar_id" and v:v=calendar_map.get(v,"default-personal")
                                values.append(v)
                            db.execute(f"INSERT INTO tasks(id,{','.join(cols)},created,modified,deleted) VALUES(?,{','.join('?' for _ in cols)},?,?,0)",[tid,*values,task.get("created",stamp),stamp])
                            pending.remove(task);progressed=True;imported+=1
                        if not progressed:break
                    for rem in workspace.get("reminders",[]):
                        mapped=idmap.get(rem.get("entity_kind","")+":"+rem.get("entity_id",""))
                        if mapped:
                            db.execute("INSERT OR IGNORE INTO reminders(id,entity_kind,entity_id,occurrence_date,offset_minutes,label,remind_at,status,snoozed_until,read_at,notified_at,created,modified) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(new_id(),rem["entity_kind"],mapped,rem.get("occurrence_date",""),rem.get("offset_minutes",0),rem.get("label",""),rem.get("remind_at",stamp),rem.get("status","scheduled"),rem.get("snoozed_until",""),rem.get("read_at",""),rem.get("notified_at",""),rem.get("created",stamp),stamp))
                    # Restore non-My-Files workspace folders (for example future editor data and attachments)
                    # while keeping the imported directory tree separate from any existing content.
                    for entry in manifest.get("files",[]):
                        archive_path=entry.get("path", "")
                        if not archive_path.startswith("payload/"):
                            continue
                        rel=safe_rel(archive_path[len("payload/"):])
                        category=rel.split("/",1)[0] if "/" in rel else rel
                        if category=="Files":
                            continue
                        tail=rel[len(category):].lstrip("/")
                        target_rel=category+"/Imported "+datetime.now().strftime('%Y-%m-%d')+("/"+tail if tail else "")
                        target=STATE.storage_path(target_rel)
                        target.parent.mkdir(parents=True,exist_ok=True)
                        if target.exists():
                            stem=target.stem; suffix=target.suffix; idx=1
                            while target.exists():
                                target=target.with_name(f"{stem} ({idx}){suffix}");idx+=1
                        target.write_bytes(zf.read(archive_path))
                    # Restore saved preferences without overwriting settings already configured here.
                    for setting in workspace.get("settings",[]):
                        db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)",(setting["key"],setting["value"]))
                    if strategy=="merge":
                        collection_map={}
                        for c in workspace.get("collections",[]):
                            cid=new_id();collection_map[c["id"]]=cid
                            db.execute("INSERT INTO collections(id,name,description,created,modified) VALUES(?,?,?,?,?)",(cid,c["name"]+" (imported)",c.get("description",""),stamp,stamp))
                        for m in workspace.get("collection_members",[]):
                            mapped= idmap.get(m["kind"]+":"+m["item_id"])
                            target_collection=collection_map.get(m["collection_id"])
                            if mapped and target_collection:
                                db.execute("INSERT OR IGNORE INTO collection_members(collection_id,kind,item_id,added) VALUES(?,?,?,?)",(target_collection,m["kind"],mapped,stamp))
                    else:
                        # The aggregate import collection contains every successfully imported content item.
                        for kind in ("file","note","bookmark","event","task"):
                            for key,mapped in idmap.items():
                                if key.startswith(kind+":"):
                                    db.execute("INSERT OR IGNORE INTO collection_members(collection_id,kind,item_id,added) VALUES(?,?,?,?)",(collection_id,kind,mapped,stamp))
                    STATE.log(db,"Workspace imported",f"{imported} content items from {stage.name}")
            stage.unlink(missing_ok=True)
            return self.send_json({"ok":True,"imported":imported,"strategy":strategy})
        except Exception:
            # Keep the validated archive in staging so the user can retry after a recoverable error.
            raise



def send_desktop_notification(title: str, body: str):
    """Best-effort OS notification without any network service or third-party package."""
    title=str(title or "NEXUS reminder")[:120];body=str(body or "A reminder is due.")[:280]
    try:
        if sys.platform == "darwin":
            safe_title=title.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
            safe_body=body.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
            subprocess.Popen(["osascript","-e",f'display notification "{safe_body}" with title "{safe_title}"'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        elif sys.platform.startswith("linux"):
            if shutil.which("notify-send"):
                subprocess.Popen(["notify-send",title,body],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        elif sys.platform == "win32":
            # Windows Forms balloon notification; PowerShell/Windows are already part of the OS.
            import base64
            title_b64=base64.b64encode(title.encode("utf-8")).decode("ascii")
            body_b64=base64.b64encode(body.encode("utf-8")).decode("ascii")
            script=("Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; "
                    "$n=New-Object System.Windows.Forms.NotifyIcon; $n.Icon=[System.Drawing.SystemIcons]::Information; "
                    f"$n.BalloonTipTitle=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{title_b64}')); "
                    f"$n.BalloonTipText=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('{body_b64}')); "
                    "$n.Visible=$true; $n.ShowBalloonTip(8000); Start-Sleep -Seconds 2; $n.Dispose()")
            subprocess.Popen(["powershell","-NoProfile","-WindowStyle","Hidden","-Command",script],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
    except Exception:
        pass


def reminder_worker():
    """Runs only while the local NEXUS service is running. Missed alerts are retained for recovery."""
    while True:
        try:
            if STATE.workspace:
                now=datetime.now(timezone.utc)
                with STATE.connect() as db:
                    handler=Handler
                    # Build the rolling reminder queue from the saved local rules.
                    dummy=None
                    # Share the same queue-generation logic without an HTTP request.
                    reminder_builder=object.__new__(Handler)
                    reminder_builder._sync_reminder_queue(db)
                    due=db.execute("SELECT * FROM reminders WHERE status IN ('scheduled','snoozed') AND COALESCE(NULLIF(snoozed_until,''),remind_at)<=? ORDER BY remind_at LIMIT 50",(now.isoformat(timespec="seconds"),)).fetchall()
                    for item in due:
                        scheduled=datetime.fromisoformat(item["snoozed_until"] or item["remind_at"])
                        late=(now-scheduled).total_seconds()
                        status="missed" if late>3600 else "notified"
                        db.execute("UPDATE reminders SET status=?,notified_at=?,modified=? WHERE id=? AND status IN ('scheduled','snoozed')",(status,now.isoformat(timespec="seconds"),now.isoformat(timespec="seconds"),item["id"]))
                        if status=="notified":
                            send_desktop_notification("NEXUS · Reminder",item["label"] or "A task or event is due.")
                    db.commit()
        except Exception as exc:
            print(f"NEXUS reminder service warning: {exc}",file=sys.stderr)
        time.sleep(15)


if __name__ == "__main__":
    import argparse
    parser=argparse.ArgumentParser(description="Run the private NEXUS local workspace")
    parser.add_argument("--port",type=int,default=8765)
    args=parser.parse_args()
    STATE.initialize_workspace()
    threading.Thread(target=reminder_worker,daemon=True,name="NEXUS-local-reminders").start()
    server=ThreadingHTTPServer(("127.0.0.1",args.port),Handler)
    server.daemon_threads=True
    print(f"NEXUS {APP_VERSION} is running locally at http://127.0.0.1:{args.port}")
    print("This server binds only to loopback. Keep this terminal open while using NEXUS.")
    try: server.serve_forever()
    except KeyboardInterrupt: print("\nNEXUS stopped.")
    finally: server.server_close()
