import sys
import unittest
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from nexus.server import local_to_utc, parse_ics_events, recurrence_dates


class RecurrenceTests(unittest.TestCase):
    def test_custom_weekdays_count(self):
        got = recurrence_dates(
            "2026-11-23",
            {"freq": "weekly", "interval": 1, "weekdays": [1, 3], "count": 5},
            date(2026, 11, 1),
            date(2026, 12, 31),
        )
        self.assertEqual([d.isoformat() for d in got], [
            "2026-11-24", "2026-11-26", "2026-12-01", "2026-12-03", "2026-12-08"
        ])

    def test_biweekly_repeats_on_original_weekday(self):
        got = recurrence_dates(
            "2026-11-23",
            {"freq": "weekly", "interval": 2, "count": 3},
            date(2026, 11, 1),
            date(2027, 1, 1),
        )
        self.assertEqual([d.isoformat() for d in got], ["2026-11-23", "2026-12-07", "2026-12-21"])

    def test_weekday_rule_skips_weekends(self):
        got = recurrence_dates(
            "2026-11-20",
            {"freq": "weekdays", "interval": 1, "count": 5},
            date(2026, 11, 20),
            date(2026, 11, 30),
        )
        self.assertEqual([d.isoformat() for d in got], [
            "2026-11-20", "2026-11-23", "2026-11-24", "2026-11-25", "2026-11-26"
        ])


class TimezoneTests(unittest.TestCase):
    def test_wall_clock_time_tracks_daylight_saving(self):
        before = local_to_utc("2026-03-07", "09:00", "America/Chicago")
        after = local_to_utc("2026-03-09", "09:00", "America/Chicago")
        self.assertEqual(before, "2026-03-07T15:00:00+00:00")
        self.assertEqual(after, "2026-03-09T14:00:00+00:00")


class ICalendarTests(unittest.TestCase):
    def test_all_day_end_date_is_exclusive_in_ics(self):
        raw = """BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nUID:day-1\r\nSUMMARY:All day\r\nDTSTART;VALUE=DATE:20261201\r\nDTEND;VALUE=DATE:20261203\r\nEND:VEVENT\r\nEND:VCALENDAR\r\n"""
        parsed = parse_ics_events(raw)
        self.assertEqual(len(parsed), 1)
        self.assertTrue(parsed[0]["all_day"])
        self.assertEqual(parsed[0]["start_date"], "2026-12-01")
        self.assertEqual(parsed[0]["end_date"], "2026-12-02")

    def test_byday_recurrence_is_parsed(self):
        raw = """BEGIN:VCALENDAR\nBEGIN:VEVENT\nUID:repeat-1\nSUMMARY:Twice weekly\nDTSTART;TZID=America/Chicago:20261123T090000\nDTEND;TZID=America/Chicago:20261123T100000\nRRULE:FREQ=WEEKLY;INTERVAL=1;BYDAY=TU,TH;COUNT=5\nEND:VEVENT\nEND:VCALENDAR\n"""
        parsed = parse_ics_events(raw)
        self.assertEqual(parsed[0]["recurrence"]["freq"], "weekly")
        self.assertEqual(parsed[0]["recurrence"]["weekdays"], [1, 3])
        self.assertEqual(parsed[0]["recurrence"]["count"], 5)


if __name__ == "__main__":
    unittest.main()
