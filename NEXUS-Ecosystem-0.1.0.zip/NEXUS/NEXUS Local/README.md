# NEXUS — Private Local Workspace

**Version 0.2.0 · Calendar & Planner update · Windows / macOS / Linux**

NEXUS is a local-first workspace that runs a small Python service on your computer and opens in your browser at `http://127.0.0.1:8765`. The existing file, note, bookmark, collection, search, privacy, and backup foundation has been extended with a calendar and personal task planner. It uses Python's standard library, SQLite, and the local file system. It does not require a hosted service, cloud account, remote database, CDN, analytics package, or third-party runtime dependency.

> This is an incremental 0.2.0 release, not the complete all-features NEXUS vision. Implemented features are listed separately from features that are not yet available.

## Start NEXUS

### Windows 10 / 11

1. Extract the `NEXUS` folder.
2. Install Python 3.10 or newer from [python.org](https://www.python.org/downloads/). During installation, enable **Add Python to PATH**.
3. Double-click `start-nexus.bat`.
4. The local service opens a browser tab at `http://127.0.0.1:8765`.
5. On first run, choose a workspace folder. For example: `C:\Users\YourUser\NEXUS`.

The service runs in its own terminal window. Keep that window open while using NEXUS. Close it or press `Ctrl+C` in that window to stop the service.

### macOS / Linux

1. Install Python 3.10 or newer.
2. Extract the `NEXUS` folder.
3. In a terminal, run:

   ```bash
   chmod +x start-nexus.sh
   ./start-nexus.sh
   ```

4. Choose a workspace folder on first run.

The service binds only to `127.0.0.1`. If port 8765 is already in use, run `python3 nexus/server.py --port 8766` (or `py -3 nexus/server.py --port 8766` on Windows), then open `http://127.0.0.1:8766`.

### Upgrade from NEXUS 0.1.0

1. Stop the old NEXUS service.
2. Make a copy of your existing workspace folder as a precaution.
3. Extract this 0.2.0 release into a new application folder (do not overwrite or delete the workspace folder).
4. Start the new `start-nexus.bat` or `start-nexus.sh` using the same operating-system account.

The app reads the existing `~/.nexus-local/config.json` workspace location and applies additive SQLite schema migrations at startup. Existing files, notes, bookmarks, collections, and activity data are retained. The migration creates the default **Personal** calendar and **My Tasks** list if they do not already exist. The upgrade path from an actual 0.1.0 workspace was exercised during this release's tests.

### Manual start

From the extracted project directory:

```bash
python nexus/server.py --port 8765
```

On Windows, use `py -3 nexus/server.py --port 8765` if `python` is not on PATH.

## What's implemented in 0.2.0

### Calendar

- Multiple local calendars with names, descriptions, colors, event counts, and visibility toggles.
- Day, week, month, year, agenda, and mixed Schedule views.
- Today, previous/next navigation, date picker, and local timezone display.
- Create, edit, duplicate, move, and delete events; event colors, categories, locations, notes, importance, and calendar selection.
- Click a date to create an event. Drag an event chip to another calendar date to move its occurrence.
- All-day events and multi-day events.
- Daily, weekday, weekly, biweekly, monthly, and yearly recurrence, with custom intervals, weekday selection, occurrence counts, or an end date.
- Recurring-series edits support one occurrence, this and future occurrences, or the entire series. Occurrence overrides are saved separately from the recurring event definition.
- Calendar search through NEXUS global search.
- ICS/iCalendar import with a preview and duplicate UID checks; ICS export; standalone calendar JSON export.

Recurring events store local calendar dates, local times, and an IANA timezone. Reminder timestamps are calculated for each occurrence using the saved timezone, so a normal 9:00 AM weekly event remains at 9:00 AM local time across daylight-saving offset changes. Unusual local times in the DST spring-forward gap or repeated fall-back hour are not given an explicit user-selectable ambiguity policy in this release.

### Tasks & Reminders

- Built-in **My Day**, **Today**, **Upcoming**, **Overdue**, **Completed**, and **All Tasks** smart lists.
- User-created task lists.
- Task title, description, due date/time, timezone, priority (None, Low, Medium, High, Urgent), status (Not started, In progress, Completed, Cancelled), category, tags, notes, pinned/starred state, and optional calendar association.
- Subtasks and completion progress.
- Daily, weekday, weekly, monthly, and yearly repeat rules. Repeating tasks create their next task when the current task is completed.
- Multiple reminder offsets per event or task, including preset intervals and comma-separated custom minutes.
- Complete, reopen, duplicate, archive, and delete task operations.
- JSON and CSV task exports. JSON includes subtasks and repeat/reminder fields.
- Global search includes event and task titles and their descriptions/notes.
- Events and tasks can be referenced from Collections without copying their original records.

### Local reminders and notification center

- Reminder schedules and notification history are stored in the local SQLite database.
- A local worker checks due reminders while the NEXUS Python service is running and attempts to send an operating-system notification.
- Windows uses the built-in PowerShell / Windows Forms notification capability; macOS uses `osascript`; Linux uses `notify-send` when it is installed.
- Notification Center shows upcoming, delivered, missed, read, snoozed, and dismissed alerts. Users can open the linked event/task, mark an alert read, snooze it, or dismiss it.
- On restart, reminders overdue by up to one hour can be delivered as late notifications; older due reminders are retained as missed so they are not silently lost or repeatedly fired.

**Closed-app limitation:** the reminder worker is part of the local NEXUS service. If the user closes the browser but leaves the local service running, the worker can still send OS notifications. If the user stops the NEXUS service or shuts down the computer, NEXUS cannot send a live notification while it is stopped. On the next start, overdue reminders are reconciled into the notification history. This build does not install a separate always-on OS daemon, scheduled task, or launch agent.

### Home dashboard

- Today's schedule and today's tasks.
- Task completion progress and overdue count.
- Upcoming events for the next seven days.
- Upcoming local reminders.
- Quick links into Calendar, Tasks, and Notification Center.

### Existing workspace foundation

- Workspace setup, SQLite database, local file manager, folders, upload/download, rename/move, duplicate, star, Trash, and restore.
- Plain-text/Markdown notes with local autosave.
- Bookmarks, folders/labels, search, and reading-list flag.
- Collections can reference files, notes, bookmarks, calendar events, and tasks.
- Global local search covers files, notes, bookmarks, events, and tasks.
- Privacy & Data shows calendar, event, task, reminder, database, and workspace storage information.
- Full NEXUS ZIP export includes calendars, events, recurrence overrides, task lists, tasks/subtasks, reminder schedules/history, settings, collections, and their relationships along with supported existing workspace content. The import workflow validates archive integrity before applying changes.

## Storage and privacy

The selected workspace contains the SQLite database at `Database/nexus.sqlite3` and the managed file folders. Calendar and planner records are stored inside that same database; they do not use a separate service or database. Backups and export archives are created within the selected local workspace.

The local service binds only to `127.0.0.1`. The application does not use a NEXUS cloud account, hosted database, remote notification provider, telemetry, analytics, external conversion API, or automatic upload. The app itself does not need an internet connection for the local planner, files, notes, or bookmarks. Opening a saved website is an explicit external browser action.

The workspace is stored as ordinary local files and a SQLite database. **Encryption at rest and workspace password protection are not implemented.** Use your operating-system account security and disk encryption if you need that protection. Anyone or any process with access to your logged-in operating-system account may be able to read the local workspace. Loopback-only binding is not a substitute for operating-system access control.

## Known limitations — not implemented yet

These items are not represented as completed features in this release:

- Native background daemon / OS scheduled task that can deliver reminders after the NEXUS Python service has been stopped.
- Browser notifications and configurable notification sounds, appearance, quiet hours, Do Not Disturb, and per-calendar notification preferences.
- Drag-resizing timed event durations; event date drag-and-drop is supported, but detailed timed-slot drag editing is not.
- A continuously moving current-time line in day/week views, global timezone preference UI, week-number toggle, and event-specific timezone selector beyond the IANA timezone field.
- Calendar JSON import (JSON export is available); full recurrence interoperability for every iCalendar extension is not guaranteed.
- Selective calendar/task import/export by date range, advanced duplicate matching beyond ICS UID checks, and CSV task import.
- Direct attachment picker/linking to existing NEXUS files, note-to-event links, bookmark-to-event links, create-task-from-note, and create-event-from-task UI. Collection references for events/tasks are supported.
- Calendar/task dashboard drag-rearrangement and widget resizing.
- Rich DOCX/PDF document editor, spreadsheet formula engine, presentation editor, and code editor.
- Gmail OAuth/API, Outlook/Microsoft Graph, Proton Mail Bridge, Yahoo Mail, email cache, unified inbox, and email attachments.
- Bookmark HTML import/export, EML/MBOX import, selective workspace export, workspace replacement import, scheduled backups, version history, full file content indexing, media previews, and encryption at rest.

No email provider is connected in this version. In particular, Proton Mail is **not** connected through ordinary IMAP; a future Proton integration must use Proton Mail Bridge as specified.

## Calendar and task export formats

- **ICS:** Calendar UI supports import with preview and export of events, including common recurrence rules.
- **Calendar JSON:** `NEXUS_CALENDAR` includes calendars, event series, recurrence overrides, and event reminder rows.
- **Task JSON:** `NEXUS_TASKS` includes task lists, task/subtask records, statuses, priorities, repeat rules, and reminder offsets.
- **Task CSV:** Includes core task fields plus serialized tags, recurrence rules, and reminder offsets.
- **Full NEXUS ZIP:** Includes supported workspace content and metadata, with integrity hashes in the archive manifest. Authentication secrets are not exported.

## Development and tests

The backend uses Python's standard library. The frontend is plain HTML, CSS, and JavaScript bundled under `nexus/static/`.

```text
NEXUS/
├── nexus/
│   ├── server.py
│   └── static/
│       ├── index.html
│       ├── styles.css
│       └── app.js
├── tests/
│   └── test_planner_logic.py
├── start-nexus.bat
└── start-nexus.sh
```

Run the included recurrence, timezone, and iCalendar parser tests with:

```bash
python -m unittest discover -s tests -v
```

The API smoke tests also exercised 0.1.0-to-0.2.0 migration, event and task creation, recurring dates, My Day filtering, collection references, reminder queue creation, search, ICS/JSON/CSV exports, and full backup packaging. A browser-based visual test could not be completed in the build environment because its Chromium browser policy blocked navigation to the local loopback server; therefore desktop/mobile rendering has not been visually certified here.
