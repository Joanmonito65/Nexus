@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python 3.10 or newer is required. Install it from python.org and try again.
  pause
  exit /b 1
)
start "NEXUS Local Service" cmd /k py -3 "%~dp0nexus\server.py" --port 8765
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8765"
echo NEXUS is running at http://127.0.0.1:8765
endlocal
