import sqlite3InitModule from '@sqlite.org/sqlite-wasm';
import { SCHEMA } from './schema.js';

let db;

async function initialize() {
  const sqlite3 = await sqlite3InitModule();
  if (!sqlite3.oo1?.OpfsDb) {
    throw new Error('Persistent SQLite OPFS storage is unavailable in this browser or deployment. NEXUS will not switch to temporary storage. Use a supported browser and a static host configured with cross-origin isolation headers.');
  }
  db = new sqlite3.oo1.OpfsDb('/nexus-browser.sqlite3');
  db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA synchronous = NORMAL;');
  db.exec(SCHEMA);
  const calendarCount = db.selectValue('SELECT COUNT(*) FROM calendars');
  if (!calendarCount) {
    db.exec({ sql: 'INSERT INTO calendars(id,name,color,description,visible,created_at) VALUES(?,?,?,?,?,?)', bind: ['cal-personal','Personal','#7665ef','Your personal calendar',1,new Date().toISOString()] });
  }
  const listCount = db.selectValue('SELECT COUNT(*) FROM task_lists');
  if (!listCount) db.exec({ sql: 'INSERT INTO task_lists(id,name,color,created_at) VALUES(?,?,?,?)', bind: ['list-default','My Tasks','#7665ef',new Date().toISOString()] });
  return { sqliteVersion: sqlite3.version.libVersion, persistent: true, storage: 'SQLite WASM · OPFS' };
}

self.onmessage = async ({ data }) => {
  const { id, type, sql, params } = data;
  try {
    if (type === 'init') {
      const result = await initialize();
      self.postMessage({ id, result });
      return;
    }
    if (!db) throw new Error('Database is not initialized.');
    if (type === 'query') {
      const rows = [];
      db.exec({ sql, bind: params || [], rowMode: 'object', resultRows: rows });
      self.postMessage({ id, result: rows });
      return;
    }
    if (type === 'run') {
      db.exec({ sql, bind: params || [] });
      self.postMessage({ id, result: { changes: db.changes(), lastInsertRowId: db.lastInsertRowid() } });
      return;
    }
    if (type === 'close') {
      db.close(); db = null;
      self.postMessage({ id, result: true });
      return;
    }
    throw new Error(`Unknown database operation: ${type}`);
  } catch (error) {
    self.postMessage({ id, error: error?.message || String(error) });
  }
};
